import { db } from '@/lib/db';

async function seed() {
  console.log('Seeding database...');

  // Create sample students with PLAIN TEXT passwords
  const students = [
    { student_id: 'STU001', roll_number: '2024-001', name: 'Aarav Sharma', email: 'aarav@example.com', password: 'student123', class: '10th', mobile: '9876543210' },
    { student_id: 'STU002', roll_number: '2024-002', name: 'Priya Patil', email: 'priya@example.com', password: 'student123', class: '10th', mobile: '9876543211' },
    { student_id: 'STU003', roll_number: '2024-003', name: 'Rohan Deshmukh', email: 'rohan@example.com', password: 'student123', class: '9th', mobile: '9876543212' },
    { student_id: 'STU004', roll_number: '2024-004', name: 'Ananya Jadhav', email: 'ananya@example.com', password: 'student123', class: '8th', mobile: '9876543213' },
    { student_id: 'STU005', roll_number: '2024-005', name: 'Karan More', email: 'karan@example.com', password: 'student123', class: '10th', mobile: '9876543214' },
  ];

  for (const s of students) {
    await db.student.upsert({
      where: { student_id: s.student_id },
      update: { password: s.password },
      create: s,
    });
  }
  console.log('Students seeded');

  const test1 = await db.test.upsert({ where: { id: 1 }, update: {}, create: { title: 'Mathematics - Chapter 1: Real Numbers', description: 'Test covering Real Numbers, Euclid\'s Division Lemma, and Fundamental Theorem of Arithmetic', duration: 30, marks_per_question: 4, class_for: '10th' } });
  const test2 = await db.test.upsert({ where: { id: 2 }, update: {}, create: { title: 'Science - Chapter 1: Chemical Reactions', description: 'Test covering Chemical Reactions and Equations', duration: 25, marks_per_question: 4, class_for: '10th' } });
  const test3 = await db.test.upsert({ where: { id: 3 }, update: {}, create: { title: 'Mathematics - Algebra Basics', description: 'Basic algebraic expressions and equations', duration: 20, marks_per_question: 2, class_for: '9th' } });

  const questions1 = [
    { question_text: 'What is the HCF of 36 and 84?', option_a: '6', option_b: '12', option_c: '18', option_d: '24', correct_answer: 'B' },
    { question_text: 'Which of the following is an irrational number?', option_a: '√4', option_b: '√9', option_c: '√5', option_d: '√16', correct_answer: 'C' },
    { question_text: 'What is the LCM of 12 and 18?', option_a: '24', option_b: '36', option_c: '48', option_d: '72', correct_answer: 'B' },
    { question_text: 'According to Euclid\'s Division Lemma, for any positive integers a and b, there exist unique integers q and r such that:', option_a: 'a = bq + r, 0 ≤ r < b', option_b: 'a = bq + r, 0 < r ≤ b', option_c: 'a = bq - r, 0 ≤ r < b', option_d: 'a = bq + r, 0 ≤ r > b', correct_answer: 'A' },
    { question_text: 'The prime factorization of 140 is:', option_a: '2² × 5 × 7', option_b: '2 × 2 × 5 × 7', option_c: '2³ × 5 × 7', option_d: 'Both A and B', correct_answer: 'D' },
    { question_text: 'If HCF(a, b) = 12 and a × b = 1800, then LCM(a, b) is:', option_a: '125', option_b: '150', option_c: '175', option_d: '200', correct_answer: 'B' },
    { question_text: 'Which number is divisible by 11?', option_a: '12345', option_b: '123432', option_c: '12321', option_d: '12122', correct_answer: 'B' },
    { question_text: 'The decimal expansion of 17/8 is:', option_a: 'Terminating', option_b: 'Non-terminating repeating', option_c: 'Non-terminating non-repeating', option_d: 'None of these', correct_answer: 'A' },
    { question_text: '√2 × √8 is equal to:', option_a: '2', option_b: '4', option_c: '8', option_d: '16', correct_answer: 'B' },
    { question_text: 'If two numbers are co-prime, then their LCM is:', option_a: '1', option_b: 'Product of the numbers', option_c: 'HCF of the numbers', option_d: 'None', correct_answer: 'B' },
  ];
  for (const q of questions1) { await db.question.upsert({ where: { id: questions1.indexOf(q) + 1 }, update: {}, create: { test_id: test1.id, ...q } }); }

  const questions2 = [
    { question_text: 'When a magnesium ribbon is burnt in air, the ash formed is:', option_a: 'Black', option_b: 'White', option_c: 'Yellow', option_d: 'Pink', correct_answer: 'B' },
    { question_text: 'Rusting of iron is a:', option_a: 'Physical change', option_b: 'Chemical change', option_c: 'Both', option_d: 'None', correct_answer: 'B' },
    { question_text: 'Which gas is evolved when dilute HCl reacts with zinc?', option_a: 'Oxygen', option_b: 'Chlorine', option_c: 'Hydrogen', option_d: 'Nitrogen', correct_answer: 'C' },
    { question_text: 'The reaction in which a single compound breaks down into two or more simpler substances is called:', option_a: 'Combination reaction', option_b: 'Decomposition reaction', option_c: 'Displacement reaction', option_d: 'Double displacement reaction', correct_answer: 'B' },
    { question_text: 'Oxidation involves:', option_a: 'Gain of oxygen', option_b: 'Loss of oxygen', option_c: 'Gain of hydrogen', option_d: 'No change', correct_answer: 'A' },
  ];
  for (const q of questions2) { await db.question.upsert({ where: { id: 10 + questions2.indexOf(q) + 1 }, update: {}, create: { test_id: test2.id, ...q } }); }

  const questions3 = [
    { question_text: 'What is the value of x if 2x + 5 = 15?', option_a: '4', option_b: '5', option_c: '6', option_d: '7', correct_answer: 'B' },
    { question_text: 'Which of the following is a polynomial?', option_a: 'x² + 1/x', option_b: '√x + 1', option_c: 'x² + 2x + 1', option_d: 'x³ + 1/x²', correct_answer: 'C' },
    { question_text: 'The degree of polynomial 3x³ + 2x² + 5x + 1 is:', option_a: '1', option_b: '2', option_c: '3', option_d: '4', correct_answer: 'C' },
    { question_text: 'Factor: x² - 9', option_a: '(x+3)(x-3)', option_b: '(x+9)(x-1)', option_c: '(x-3)²', option_d: '(x+3)²', correct_answer: 'A' },
    { question_text: 'If (x + 1) is a factor of x² + px + 5, then p is:', option_a: '5', option_b: '-5', option_c: '6', option_d: '-6', correct_answer: 'C' },
  ];
  for (const q of questions3) { await db.question.upsert({ where: { id: 20 + questions3.indexOf(q) + 1 }, update: {}, create: { test_id: test3.id, ...q } }); }

  await db.test.update({ where: { id: test1.id }, data: { total_questions: questions1.length } });
  await db.test.update({ where: { id: test2.id }, data: { total_questions: questions2.length } });
  await db.test.update({ where: { id: test3.id }, data: { total_questions: questions3.length } });

  console.log('Database seeding complete!');
}

seed().catch(console.error);
