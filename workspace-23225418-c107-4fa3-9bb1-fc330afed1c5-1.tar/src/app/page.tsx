'use client';

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  GraduationCap, BookOpen, Clock, Shield, Users, Trophy, ChevronRight,
  Menu, X, Eye, EyeOff, LogOut, Plus, Trash2, Edit, Search, Upload,
  Printer, ArrowLeft, ArrowRight, CheckCircle, XCircle, AlertTriangle,
  Phone, Mail, MapPin, Star, Award, FileText, BarChart3,
  Globe, Monitor, Lock, KeyRound, User, BookMarked,
  Timer, Fullscreen, AlertOctagon, Ban,
  Sparkles, TrendingUp, Target, Zap, BookCopy, Layers,
  ChevronDown, Home, Info, CheckCheck, GraduationCapIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { useAppStore, type Test, type Question, type ExamResult, type DetailedAnswer } from '@/lib/store';

/* ═══════════════════════ TRANSLATIONS ═══════════════════════ */
const T = {
  en: {
    home: 'Home', about: 'About', courses: 'Courses', contact: 'Contact',
    register: 'Register', studentLogin: 'Student Login', adminLogin: 'Admin',
    heroTitle: 'Shrinath Chanakya', heroSub: 'Coaching Classes',
    heroLine: 'Excellence in Education | Pune, Maharashtra',
    heroDesc: 'Empowering students with modern online examination system. Join 500+ successful students!',
    features: 'Why Choose Us?', onlineExam: 'Online Exams', instantResult: 'Instant Results',
    antiCheat: 'Anti-Cheating', classWise: 'Class-wise Tests',
    onExamD: 'Take exams from anywhere with our advanced platform', onResD: 'Detailed analysis with instant score breakdown', onAntiD: 'Fullscreen, tab detection & smart monitoring', onClassD: 'Each class gets its own dedicated tests',
    courses: 'Our Courses', classes: 'Classes', medium: 'Medium', contactUs: 'Contact Us',
    sendMessage: 'Send', name: 'Name', email: 'Email', mobile: 'Mobile', password: 'Password',
    cls: 'Class', selCls: 'Select Class', roll: 'Roll No.', stuId: 'Student ID / Email',
    login: 'Login', logout: 'Logout', dash: 'Dashboard', availTests: 'Available Tests',
    startTest: 'Start', prevResults: 'Past Results', viewRes: 'Details', score: 'Score',
    pct: 'Percentage', total: 'Total', detailed: 'Answer Details', q: 'Question',
    correct: 'Correct', wrong: 'Wrong', print: 'Print', back: 'Back',
    addTest: 'Add Test', editTest: 'Edit', delTest: 'Delete', upTest: 'Upload Test',
    title: 'Title', desc: 'Description', dur: 'Duration (min)', mpq: 'Marks/Q',
    addQ: '+ Question', save: 'Save', cancel: 'Cancel', search: 'Search...',
    stuRec: 'Students', addStu: 'Add Student', editStu: 'Edit', delStu: 'Delete',
    noTests: 'No tests available', noRes: 'No results yet', instr: 'Instructions',
    startExam: 'Start Exam', submit: 'Submit Exam', timeLeft: 'Time Left',
    viol: 'Violation', fsWarn: 'Stay in fullscreen!', enterFS: 'Enter Fullscreen & Start',
    autoSub: 'Auto-submitted (violations)', timeUp: 'Time Up! Submitted.',
    subOk: 'Submitted!', totStu: 'Students', totTest: 'Tests', totRes: 'Results',
    engMed: 'English Medium', engSemi: 'English Semi', marMed: 'Marathi Medium',
    allCls: 'All', optA: 'A', optB: 'B', optC: 'C', optD: 'D', cAns: 'Answer',
    welcome: 'Welcome', yourCls: 'Class', taken: 'Already taken',
    reg: 'Online Registration', regNow: 'Register Now', msg: 'Message',
    selMed: 'Select Medium', regOk: 'Registered!', file: 'Upload (TXT/PDF)',
    noStu: 'No students', stats: 'Stats', aboutUs: 'About', founder: 'Founder',
    mission: 'Mission', vision: 'Vision', qNo: '#', yourAns: 'Yours',
    marks: 'Marks', status: 'Status', showPwd: 'Show Password', hidePwd: 'Hide Password',
    aboutD: 'Shrinath Chanakya Coaching Classes is a premier coaching institute in Pune, founded by Sasane Sir & Shinde Sir, providing quality education from 5th to 10th standard across all mediums.',
    missD: 'To provide affordable, quality education empowering every student to achieve academic excellence.', visD: 'To be the most trusted coaching institute in Pune, known for innovative teaching methods.',
    subjects: 'Subjects', math: 'Mathematics', sci: 'Science', eng: 'English',
    mar: 'Marathi', hin: 'Hindi', socSci: 'Social Science',
  },
  mr: {
    home: 'मुख्यपृष्ठ', about: 'आमच्याबद्दल', courses: 'अभ्यासक्रम', contact: 'संपर्क',
    register: 'नोंदणी', studentLogin: 'विद्यार्थी लॉगिन', adminLogin: 'ॲडमिन',
    heroTitle: 'श्रीनाथ चाणक्य', heroSub: 'कोचिंग क्लासेस',
    heroLine: 'शैक्षणिक उत्कृष्टता | पुणे, महाराष्ट्र',
    heroDesc: 'आधुनिक ऑनलाइन परीक्षा प्रणालीसह विद्यार्थ्यांना सक्षम करणे. ५००+ यशस्वी विद्यार्थी सामील व्हा!',
    features: 'आम्हीच का निवडा?', onlineExam: 'ऑनलाइन परीक्षा', instantResult: 'तत्काळ निकाल',
    antiCheat: 'गैर-कृत्य रोख', classWise: 'वर्गानुसार चाचणी',
    onExamD: 'आमच्या प्रगत प्लॅटफॉर्मवर कुठूनही परीक्षा द्या', onResD: 'तपशीलवार विश्लेषण आणि तत्काळ गुण',
    onAntiD: 'फुलस्क्रीन, टॅब डिटेक्शन आणि स्मार्ट मॉनिटरिंग', onClassD: 'प्रत्येक वर्गासाठी वेगळी चाचणी',
    courses: 'अभ्यासक्रम', classes: 'वर्ग', medium: 'माध्यम', contactUs: 'संपर्क करा',
    sendMessage: 'पाठवा', name: 'नाव', email: 'ईमेल', mobile: 'मोबाईल', password: 'पासवर्ड',
    cls: 'वर्ग', selCls: 'वर्ग निवडा', roll: 'रोल नंबर', stuId: 'विद्यार्थी आयडी / ईमेल',
    login: 'लॉगिन', logout: 'लॉगआउट', dash: 'डॅशबोर्ड', availTests: 'उपलब्ध चाचण्या',
    startTest: 'सुरू', prevResults: 'मागील निकाल', viewRes: 'तपशील', score: 'गुण',
    pct: 'टक्केवारी', total: 'एकूण', detailed: 'उत्तरे', q: 'प्रश्न',
    correct: 'बरोबर', wrong: 'चुकीचे', print: 'मुद्रित', back: 'परत',
    addTest: 'चाचणी जोडा', editTest: 'संपादित', delTest: 'हटवा', upTest: 'अपलोड',
    title: 'शीर्षक', desc: 'वर्णन', dur: 'कालावधी (मिनि)', mpq: 'गुण/प्रश्न',
    addQ: '+ प्रश्न', save: 'जतन', cancel: 'रद्द', search: 'शोधा...',
    stuRec: 'विद्यार्थी', addStu: 'विद्यार्थी जोडा', editStu: 'संपादित', delStu: 'हटवा',
    noTests: 'चाचण्या नाहीत', noRes: 'निकाल नाहीत', instr: 'सूचना',
    startExam: 'परीक्षा सुरू', submit: 'सबमिट', timeLeft: 'शिल्लक वेळ',
    viol: 'उल्लंघन', fsWarn: 'फुलस्क्रीनमध्ये रहा!', enterFS: 'फुलस्क्रीन & सुरू करा',
    autoSub: 'ऑटो-सबमिट', timeUp: 'वेळ संपली!',
    subOk: 'सबमिट!', totStu: 'विद्यार्थी', totTest: 'चाचण्या', totRes: 'निकाल',
    engMed: 'इंग्रजी माध्यम', engSemi: 'इंग्रजी सेमी', marMed: 'मराठी माध्यम',
    allCls: 'सर्व', optA: 'अ', optB: 'ब', optC: 'क', optD: 'ड', cAns: 'उत्तर',
    welcome: 'स्वागत', yourCls: 'वर्ग', taken: 'आधीच दिली',
    reg: 'ऑनलाइन नोंदणी', regNow: 'नोंदणी', msg: 'संदेश',
    selMed: 'माध्यम', regOk: 'नोंदणी झाली!', file: 'अपलोड (TXT/PDF)',
    noStu: 'विद्यार्थी नाहीत', stats: 'आकडेवारी', aboutUs: 'आमच्याबद्दल', founder: 'संस्थापक',
    mission: 'ध्येय', vision: 'दृष्टी', qNo: 'क्र.', yourAns: 'तुमचे',
    marks: 'गुण', status: 'स्थिती', showPwd: 'पासवर्ड दाखवा', hidePwd: 'पासवर्ड लपवा',
    aboutD: 'श्रीनाथ चाणक्य कोचिंग क्लासेस ही पुण्यातील प्रमुख संस्था. सासणे सर व शिंदे सर यांनी स्थापित, ५वी ते १०वी इयत्तेचे गुणवत्तापूर्ण शिक्षण.',
    missD: 'प्रत्येक विद्यार्थ्याला शैक्षणिक उत्कृष्टता साध्य करण्यासाठी परवडणारी शिक्षण.',
    visD: 'अभिनव शिक्षण पद्धतींसाठी पुण्यातील सर्वात विश्वसनीय संस्था.',
    subjects: 'विषय', math: 'गणित', sci: 'विज्ञान', eng: 'इंग्रजी',
    mar: 'मराठी', hin: 'हिंदी', socSci: 'सामाजिक शास्त्र',
  }
};
const CLS = ['5th', '6th', '7th', '8th', '9th', '10th'];
const MEDS = ['English Medium', 'English Semi', 'Marathi Medium'];

/* ═══════════════════════ MAIN PAGE ═══════════════════════ */
export default function Page() {
  const { currentPage, lang } = useAppStore();
  const [mob, setMob] = useState(false);
  const tr = T[lang];
  const pages: Record<string, React.ReactNode> = {
    home: <HomePage />, about: <AboutPage />, courses: <CoursesPage />, contact: <ContactPage />,
    register: <RegisterPage />, 'student-login': <StudentLoginPage />, 'admin-login': <AdminLoginPage />,
    'student-dashboard': <StudentDash />, 'student-exam': <ExamPage />, 'student-result': <ResultPage />,
    'student-results-list': <ResultPage />, 'admin-dashboard': <AdminDash />,
    'admin-add-test': <AddTestPage />, 'admin-edit-test': <EditTestPage />,
    'admin-upload-test': <UploadTestPage />, 'admin-add-student': <AddStuPage />,
    'admin-students': <StuListPage />, 'admin-view-student': <ViewStuResPage />,
  };
  return (
    <div className="min-h-screen flex flex-col bg-[#fafbfc]">
      <Nav mob={mob} setMob={setMob} tr={tr} />
      <main className="flex-1 page-transition">{pages[currentPage] || <HomePage />}</main>
      <Foot tr={tr} />
    </div>
  );
}

/* ═══════════════════════ NAVBAR ═══════════════════════ */
function Nav({ mob, setMob, tr }: { mob: boolean; setMob: (v: boolean) => void; tr: typeof T.en }) {
  const { lang, setLang, currentPage, setCurrentPage, isStudentLoggedIn, isAdminLoggedIn, studentLogout, adminLogout } = useAppStore();
  const items = [
    { l: tr.home, p: 'home' as const }, { l: tr.about, p: 'about' as const },
    { l: tr.courses, p: 'courses' as const }, { l: tr.contact, p: 'contact' as const },
  ];
  const go = (p: string) => { setCurrentPage(p as never); setMob(false); };
  const out = () => { studentLogout(); adminLogout(); setMob(false); };
  return (
    <header className="sticky top-0 z-50 glass border-b border-white/20 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <button onClick={() => go('home')} className="flex items-center gap-2.5 group">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/20 group-hover:shadow-emerald-500/40 transition-shadow">
              <GraduationCap className="h-5 w-5 text-white" />
            </div>
            <div className="hidden sm:block">
              <div className="font-extrabold text-gray-900 text-sm leading-none tracking-tight">Shrinath Chanakya</div>
              <div className="text-[10px] text-gray-400 font-medium">Coaching Classes</div>
            </div>
          </button>
          <nav className="hidden lg:flex items-center gap-1">
            {items.map(i => (
              <Button key={i.p} variant="ghost" size="sm" onClick={() => setCurrentPage(i.p)}
                className={`${currentPage === i.p ? 'bg-emerald-50 text-emerald-700 font-semibold' : 'text-gray-500 hover:text-gray-900'} rounded-lg text-sm`}>
                {i.l}
              </Button>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => setLang(lang === 'en' ? 'mr' : 'en')}
              className="hidden sm:flex h-8 w-8 rounded-lg text-gray-400 hover:text-emerald-600">
              <Globe className="h-4 w-4" />
            </Button>
            {(isStudentLoggedIn || isAdminLoggedIn) ? (
              <div className="flex items-center gap-1.5">
                <Button variant="ghost" size="sm" onClick={() => setCurrentPage(isStudentLoggedIn ? 'student-dashboard' : 'admin-dashboard')} className="text-emerald-700 text-xs rounded-lg">
                  <BarChart3 className="h-3.5 w-3.5 mr-1" />{tr.dash}
                </Button>
                <Button variant="ghost" size="sm" onClick={out} className="text-red-500 hover:text-red-600 text-xs rounded-lg">
                  <LogOut className="h-3.5 w-3.5 mr-1" />{tr.logout}
                </Button>
              </div>
            ) : (
              <div className="hidden sm:flex items-center gap-1.5">
                <Button variant="ghost" size="sm" onClick={() => setCurrentPage('register')} className="text-gray-600 text-xs rounded-lg">{tr.register}</Button>
                <Button variant="ghost" size="sm" onClick={() => setCurrentPage('student-login')} className="text-emerald-700 text-xs rounded-lg">{tr.studentLogin}</Button>
                <Button size="sm" onClick={() => setCurrentPage('admin-login')}
                  className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-lg text-xs shadow-md shadow-emerald-500/20">
                  <Shield className="h-3.5 w-3.5 mr-1" />{tr.adminLogin}
                </Button>
              </div>
            )}
            <Sheet open={mob} onOpenChange={setMob}>
              <SheetTrigger asChild className="lg:hidden"><Button variant="ghost" size="icon" className="h-9 w-9 rounded-lg"><Menu className="h-5 w-5" /></Button></SheetTrigger>
              <SheetContent side="right" className="w-72 p-0">
                <div className="flex flex-col h-full bg-white">
                  <div className="p-6 bg-gradient-to-br from-emerald-600 to-teal-700 text-white">
                    <GraduationCap className="h-10 w-10 mb-2 opacity-90" />
                    <div className="font-extrabold text-lg">Shrinath Chanakya</div>
                    <div className="text-emerald-200 text-xs">Coaching Classes</div>
                  </div>
                  <ScrollArea className="flex-1 p-4">
                    <div className="space-y-1">
                      {items.map(i => (
                        <Button key={i.p} variant="ghost" className="w-full justify-start rounded-lg text-sm" onClick={() => go(i.p)}>{i.l}</Button>
                      ))}
                      <Separator className="my-3" />
                      <Button variant="ghost" size="sm" onClick={() => setLang(lang === 'en' ? 'mr' : 'en')} className="w-full justify-start rounded-lg"><Globe className="h-4 w-4 mr-2" />{lang === 'en' ? 'मराठी' : 'English'}</Button>
                      {!isStudentLoggedIn && !isAdminLoggedIn && <>
                        <Button variant="outline" className="w-full rounded-lg mt-2" onClick={() => go('register')}>{tr.register}</Button>
                        <Button variant="outline" className="w-full rounded-lg" onClick={() => go('student-login')}>{tr.studentLogin}</Button>
                        <Button className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-lg" onClick={() => go('admin-login')}>{tr.adminLogin}</Button>
                      </>}
                      {(isStudentLoggedIn || isAdminLoggedIn) && (
                        <Button variant="destructive" className="w-full rounded-lg mt-2" onClick={out}><LogOut className="h-4 w-4 mr-2" />{tr.logout}</Button>
                      )}
                    </div>
                  </ScrollArea>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}

/* ═══════════════════════ FOOTER ═══════════════════════ */
function Foot({ tr }: { tr: typeof T.en }) {
  return (
    <footer className="bg-gray-950 text-gray-300 mt-auto">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                <GraduationCap className="h-5 w-5 text-white" />
              </div>
              <span className="font-extrabold text-white">Shrinath Chanakya</span>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed">{tr.aboutD.slice(0, 120)}...</p>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">{tr.contactUs}</h4>
            <div className="space-y-3 text-sm">
              <a href="tel:+919881296727" className="flex items-center gap-2.5 hover:text-emerald-400 transition-colors"><Phone className="h-4 w-4 text-emerald-500" />+91 9881296727</a>
              <a href="mailto:info@shrinathchanakya.com" className="flex items-center gap-2.5 hover:text-emerald-400 transition-colors"><Mail className="h-4 w-4 text-emerald-500" />info@shrinathchanakya.com</a>
              <div className="flex items-center gap-2.5"><MapPin className="h-4 w-4 text-emerald-500" />Pune, Maharashtra, India</div>
            </div>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Developed By</h4>
            <div className="space-y-2 text-sm text-gray-400">
              <p>Sasane Sir & Shinde Sir</p>
              <p>Shrinath Chanakya Coaching Classes</p>
              <div className="flex gap-2 pt-2">
                <Badge variant="outline" className="border-gray-700 text-gray-400 text-[10px]">Next.js</Badge>
                <Badge variant="outline" className="border-gray-700 text-gray-400 text-[10px]">React</Badge>
                <Badge variant="outline" className="border-gray-700 text-gray-400 text-[10px]">Prisma</Badge>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-10 pt-6 border-t border-gray-800 text-center text-xs text-gray-500">
          &copy; {new Date().getFullYear()} Shrinath Chanakya Coaching Classes. All Rights Reserved.
        </div>
      </div>
    </footer>
  );
}

/* ═══════════════════════ HOME ═══════════════════════ */
function HomePage() {
  const { lang, setCurrentPage } = useAppStore();
  const tr = T[lang];
  const feats = [
    { icon: Monitor, t: tr.onlineExam, d: tr.onExamD, c: 'from-violet-500 to-purple-600', sc: 'shadow-violet-500/20' },
    { icon: TrendingUp, t: tr.instantResult, d: tr.onResD, c: 'from-amber-500 to-orange-600', sc: 'shadow-amber-500/20' },
    { icon: Shield, t: tr.antiCheat, d: tr.onAntiD, c: 'from-rose-500 to-red-600', sc: 'shadow-rose-500/20' },
    { icon: Layers, t: tr.classWise, d: tr.onClassD, c: 'from-cyan-500 to-blue-600', sc: 'shadow-cyan-500/20' },
  ];
  const stats = [
    { n: '500+', l: tr.totStu, icon: Users },
    { n: '50+', l: tr.totTest, icon: FileText },
    { n: '95%', l: 'Pass Rate', icon: Trophy },
    { n: '6', l: tr.cls, icon: BookOpen },
  ];
  const reviews = [
    { n: 'Aarav Sharma', c: '10th', t: 'Online test system helped me practice a lot. Got excellent marks in board exams!' },
    { n: 'Priya Patil', c: '10th', t: 'Anti-cheating ensures fair exams. Instant results are amazing!' },
    { n: 'Rohan Deshmukh', c: '9th', t: 'Best coaching in Pune! Teachers are very supportive.' },
  ];
  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-800 via-teal-800 to-emerald-950" />
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '40px 40px' }} />
        <div className="absolute top-20 left-10 w-[500px] h-[500px] bg-emerald-400/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-teal-400/10 rounded-full blur-3xl" />
        <div className="relative max-w-7xl mx-auto px-4 py-20 md:py-32 text-center">
          <Badge className="bg-white/10 text-emerald-200 border-white/10 mb-6 text-xs px-4 py-1.5 backdrop-blur-sm">
            <Sparkles className="h-3 w-3 mr-1.5" />Trusted by 500+ Students Across Pune
          </Badge>
          <h1 className="text-4xl sm:text-5xl md:text-7xl font-black text-white mb-3 leading-[1.1] tracking-tight">
            {tr.heroTitle}
          </h1>
          <div className="text-xl sm:text-2xl md:text-3xl font-semibold text-emerald-300/90 mb-4">{tr.heroSub}</div>
          <p className="text-emerald-200/60 text-sm md:text-base max-w-xl mx-auto mb-8">{tr.heroLine}<br />{tr.heroDesc}</p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button size="lg" onClick={() => setCurrentPage('register')}
              className="bg-white text-emerald-800 hover:bg-emerald-50 font-bold px-8 h-12 rounded-xl shadow-lg shadow-black/10 text-sm">
              {tr.regNow} <ChevronRight className="ml-1.5 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" onClick={() => setCurrentPage('student-login')}
              className="border-white/20 text-white hover:bg-white/10 px-8 h-12 rounded-xl text-sm">
              {tr.studentLogin} <ArrowRight className="ml-1.5 h-4 w-4" />
            </Button>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0"><svg viewBox="0 0 1440 60" fill="none"><path d="M0 60V30C240 10 480 0 720 10C960 20 1200 40 1440 30V60H0Z" fill="#fafbfc"/></svg></div>
      </section>

      {/* STATS */}
      <section className="py-10 md:py-14">
        <div className="max-w-5xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {stats.map((s, i) => (
            <div key={i} className="modern-card rounded-2xl p-5 md:p-6 text-center group cursor-default">
              <s.icon className="h-7 w-7 text-emerald-500 mx-auto mb-2 group-hover:scale-110 transition-transform" />
              <div className="text-2xl md:text-3xl font-black text-gray-900">{s.n}</div>
              <div className="text-xs text-gray-400 font-medium mt-0.5">{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURES */}
      <section className="py-16 md:py-20 bg-gradient-to-b from-transparent via-emerald-50/50 to-transparent">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 text-xs mb-3">Features</Badge>
            <h2 className="text-3xl md:text-4xl font-black text-gray-900 tracking-tight">{tr.features}</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {feats.map((f, i) => (
              <div key={i} className="modern-card rounded-2xl p-6 md:p-8 group cursor-default">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${f.c} flex items-center justify-center mb-4 shadow-lg ${f.sc} group-hover:scale-110 transition-transform`}>
                  <f.icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="font-bold text-gray-900 mb-1.5">{f.t}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{f.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-16 md:py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <Badge className="bg-amber-100 text-amber-700 border-amber-200 text-xs mb-3">Testimonials</Badge>
            <h2 className="text-3xl md:text-4xl font-black text-gray-900 tracking-tight">Student Reviews</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {reviews.map((r, i) => (
              <div key={i} className="modern-card rounded-2xl p-6">
                <div className="flex gap-0.5 mb-3">{[...Array(5)].map((_, j) => <Star key={j} className="h-4 w-4 fill-amber-400 text-amber-400" />)}</div>
                <p className="text-gray-600 text-sm leading-relaxed mb-4 italic">&ldquo;{r.t}&rdquo;</p>
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10 bg-gradient-to-br from-emerald-400 to-teal-500"><AvatarFallback className="text-white font-bold text-xs">{r.n.split(' ').map(w => w[0]).join('')}</AvatarFallback></Avatar>
                  <div><div className="font-semibold text-gray-900 text-sm">{r.n}</div><div className="text-[11px] text-gray-400">Class {r.c}</div></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 md:py-20">
        <div className="max-w-4xl mx-auto px-4">
          <div className="relative rounded-3xl overflow-hidden p-10 md:p-16 text-center">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-600 via-teal-600 to-emerald-700" />
            <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '30px 30px' }} />
            <div className="relative">
              <h2 className="text-2xl md:text-4xl font-black text-white mb-3">Ready to Start Learning?</h2>
              <p className="text-emerald-200/70 mb-8 text-sm md:text-base">Join Shrinath Chanakya Coaching Classes today!</p>
              <Button size="lg" onClick={() => setCurrentPage('register')} className="bg-white text-emerald-800 hover:bg-emerald-50 font-bold px-8 h-12 rounded-xl shadow-lg text-sm">
                {tr.regNow} <ChevronRight className="ml-1.5 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

/* ═══════════════════════ ABOUT ═══════════════════════ */
function AboutPage() {
  const { lang } = useAppStore();
  const tr = T[lang];
  return (
    <div className="max-w-5xl mx-auto px-4 py-12 md:py-16 page-transition">
      <div className="text-center mb-14">
        <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 text-xs mb-3">About Us</Badge>
        <h1 className="text-3xl md:text-5xl font-black text-gray-900 tracking-tight">{tr.aboutUs}</h1>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        {[
          { n: 'Sasane Sir', sub: tr.founder, d: lang === 'mr' ? 'गणित तज्ञ. १५+ वर्षांचा अनुभव.' : 'Mathematics Expert. 15+ years experience.', ini: 'SS' },
          { n: 'Shinde Sir', sub: tr.founder, d: lang === 'mr' ? 'विज्ञान तज्ञ. १२+ वर्षांचा अनुभव.' : 'Science Expert. 12+ years experience.', ini: 'SK' },
        ].map((p, i) => (
          <div key={i} className="modern-card rounded-2xl p-8 text-center">
            <Avatar className="h-20 w-20 mx-auto mb-4 bg-gradient-to-br from-emerald-400 to-teal-500 shadow-lg shadow-emerald-500/20"><AvatarFallback className="text-white font-black text-xl">{p.ini}</AvatarFallback></Avatar>
            <h3 className="text-xl font-bold text-gray-900">{p.n}</h3>
            <p className="text-emerald-600 text-sm font-medium mb-3">{p.sub}</p>
            <p className="text-gray-500 text-sm">{p.d}</p>
          </div>
        ))}
      </div>
      <p className="text-gray-600 leading-relaxed mb-10 max-w-3xl mx-auto text-center">{tr.aboutD}</p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[{ ic: Target, t: tr.mission, d: tr.missD }, { ic: Zap, t: tr.vision, d: tr.visD }].map((c, i) => (
          <div key={i} className="modern-card rounded-2xl p-8">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center mb-4 shadow-lg shadow-emerald-500/20">
              <c.ic className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">{c.t}</h3>
            <p className="text-gray-500 text-sm leading-relaxed">{c.d}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════ COURSES ═══════════════════════ */
function CoursesPage() {
  const { lang } = useAppStore();
  const tr = T[lang];
  const subs = [
    { n: tr.math, c: 'from-blue-500 to-indigo-600', sc: 'shadow-blue-500/20' },
    { n: tr.sci, c: 'from-green-500 to-emerald-600', sc: 'shadow-green-500/20' },
    { n: tr.eng, c: 'from-purple-500 to-violet-600', sc: 'shadow-purple-500/20' },
    { n: tr.mar, c: 'from-orange-500 to-amber-600', sc: 'shadow-orange-500/20' },
    { n: tr.hin, c: 'from-rose-500 to-red-600', sc: 'shadow-rose-500/20' },
    { n: tr.socSci, c: 'from-teal-500 to-cyan-600', sc: 'shadow-teal-500/20' },
  ];
  return (
    <div className="max-w-6xl mx-auto px-4 py-12 md:py-16 page-transition">
      <div className="text-center mb-14">
        <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 text-xs mb-3">Academics</Badge>
        <h1 className="text-3xl md:text-5xl font-black text-gray-900 tracking-tight">{tr.courses}</h1>
        <p className="text-gray-400 mt-2 text-sm">5th to 10th | {tr.engMed} | {tr.engSemi} | {tr.marMed}</p>
      </div>
      <div className="mb-12">
        <h2 className="text-xl font-bold text-gray-900 mb-6">{tr.subjects}</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {subs.map((s, i) => (
            <div key={i} className="modern-card rounded-2xl p-5 text-center group cursor-default">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${s.c} flex items-center justify-center mx-auto mb-3 shadow-lg ${s.sc} group-hover:scale-110 transition-transform`}>
                <BookCopy className="h-6 w-6 text-white" />
              </div>
              <div className="font-semibold text-gray-900 text-sm">{s.n}</div>
            </div>
          ))}
        </div>
      </div>
      <h2 className="text-xl font-bold text-gray-900 mb-6">{tr.medium}</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {MEDS.map((m, i) => (
          <div key={i} className="modern-card rounded-2xl p-6 text-center">
            <Globe className="h-10 w-10 text-emerald-500 mx-auto mb-3" />
            <h3 className="font-bold text-gray-900 text-lg mb-1">{m}</h3>
            <p className="text-gray-400 text-xs">{CLS.map(c => c).join(' • ')}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════ CONTACT ═══════════════════════ */
function ContactPage() {
  const { lang } = useAppStore();
  const tr = T[lang];
  const [f, setF] = useState({ name: '', email: '', mobile: '', message: '' });
  const [ld, setLd] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setLd(true);
    try { const r = await fetch('/api/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(f) }); const d = await r.json(); d.success ? (toast.success(tr.regOk), setF({ name: '', email: '', mobile: '', message: '' })) : toast.error(d.message); } catch { toast.error('Error'); }
    setLd(false);
  };
  const infos = [
    { ic: Phone, t: tr.mobile, v: '+91 9881296727', href: 'tel:+919881296727' },
    { ic: Mail, t: tr.email, v: 'info@shrinathchanakya.com', href: 'mailto:info@shrinathchanakya.com' },
    { ic: MapPin, t: 'Address', v: 'Pune, Maharashtra, India', href: '' },
  ];
  return (
    <div className="max-w-6xl mx-auto px-4 py-12 md:py-16 page-transition">
      <div className="text-center mb-14">
        <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 text-xs mb-3">Get in Touch</Badge>
        <h1 className="text-3xl md:text-5xl font-black text-gray-900 tracking-tight">{tr.contactUs}</h1>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
        <div className="md:col-span-3 modern-card rounded-2xl p-6 md:p-8">
          <form onSubmit={submit} className="space-y-4">
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{tr.name}</Label><Input required value={f.name} onChange={e => setF({ ...f, name: e.target.value })} className="mt-1.5 rounded-xl h-11" placeholder="Your name" /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{tr.email}</Label><Input required type="email" value={f.email} onChange={e => setF({ ...f, email: e.target.value })} className="mt-1.5 rounded-xl h-11" placeholder="your@email.com" /></div>
              <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{tr.mobile}</Label><Input required value={f.mobile} onChange={e => setF({ ...f, mobile: e.target.value })} className="mt-1.5 rounded-xl h-11" placeholder="+91 ..." /></div>
            </div>
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{tr.msg}</Label><Textarea rows={4} value={f.message} onChange={e => setF({ ...f, message: e.target.value })} className="mt-1.5 rounded-xl" placeholder="Your message..." /></div>
            <Button type="submit" disabled={ld} className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl h-11 font-semibold text-sm shadow-lg shadow-emerald-500/20">
              {ld ? '...' : <><Mail className="h-4 w-4 mr-2" />{tr.sendMessage}</>}
            </Button>
          </form>
        </div>
        <div className="md:col-span-2 space-y-4">
          {infos.map((c, i) => (
            <a key={i} href={c.href} className={c.href ? '' : 'pointer-events-none'}>
              <div className="modern-card rounded-2xl p-5 flex items-center gap-4 group">
                <div className="w-11 h-11 rounded-xl bg-emerald-50 flex items-center justify-center shrink-0 group-hover:bg-emerald-100 transition-colors"><c.ic className="h-5 w-5 text-emerald-600" /></div>
                <div><div className="text-[10px] text-gray-400 font-semibold uppercase tracking-wider">{c.t}</div><div className="text-sm font-semibold text-gray-900">{c.v}</div></div>
              </div>
            </a>
          ))}
          <div className="modern-card rounded-2xl h-44 flex items-center justify-center text-gray-300 overflow-hidden">
            <div className="text-center"><MapPin className="h-10 w-10 mx-auto mb-2 opacity-40" /><span className="text-xs">Pune, Maharashtra</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════ REGISTER ═══════════════════════ */
function RegisterPage() {
  const { lang } = useAppStore();
  const tr = T[lang];
  const [f, setF] = useState({ name: '', email: '', mobile: '', class: '10th', medium: 'English Medium', message: '' });
  const [ld, setLd] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setLd(true);
    try { const r = await fetch('/api/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(f) }); const d = await r.json(); d.success ? (toast.success(tr.regOk), setF({ name: '', email: '', mobile: '', class: '10th', medium: 'English Medium', message: '' })) : toast.error(d.message); } catch { toast.error('Error'); }
    setLd(false);
  };
  return (
    <div className="max-w-lg mx-auto px-4 py-12 page-transition">
      <div className="modern-card rounded-2xl p-8 shadow-xl shadow-gray-200/50">
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-emerald-500/20"><GraduationCap className="h-7 w-7 text-white" /></div>
          <h1 className="text-2xl font-black text-gray-900">{tr.reg}</h1>
        </div>
        <form onSubmit={submit} className="space-y-4">
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{tr.name}</Label><Input required value={f.name} onChange={e => setF({ ...f, name: e.target.value })} className="mt-1 rounded-xl h-11" /></div>
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{tr.email}</Label><Input required type="email" value={f.email} onChange={e => setF({ ...f, email: e.target.value })} className="mt-1 rounded-xl h-11" /></div>
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{tr.mobile}</Label><Input required value={f.mobile} onChange={e => setF({ ...f, mobile: e.target.value })} className="mt-1 rounded-xl h-11" /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{tr.cls}</Label>
              <Select value={f.class} onValueChange={v => setF({ ...f, class: v })}><SelectTrigger className="mt-1 rounded-xl h-11"><SelectValue /></SelectTrigger><SelectContent>{CLS.map(c => <SelectItem key={c} value={c}>Class {c}</SelectItem>)}</SelectContent></Select>
            </div>
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{tr.medium}</Label>
              <Select value={f.medium} onValueChange={v => setF({ ...f, medium: v })}><SelectTrigger className="mt-1 rounded-xl h-11"><SelectValue /></SelectTrigger><SelectContent>{MEDS.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent></Select>
            </div>
          </div>
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{tr.msg}</Label><Textarea rows={2} value={f.message} onChange={e => setF({ ...f, message: e.target.value })} className="mt-1 rounded-xl" /></div>
          <Button type="submit" disabled={ld} className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl h-11 font-bold text-sm shadow-lg shadow-emerald-500/20">{ld ? '...' : tr.regNow}</Button>
        </form>
      </div>
    </div>
  );
}

/* ═══════════════════════ STUDENT LOGIN ═══════════════════════ */
function StudentLoginPage() {
  const { lang, studentLogin } = useAppStore();
  const tr = T[lang];
  const [f, setF] = useState({ student_id: '', password: '' });
  const [show, setShow] = useState(false);
  const [ld, setLd] = useState(false);
  const go = async (e: React.FormEvent) => {
    e.preventDefault(); setLd(true);
    try { const r = await fetch('/api/student/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(f) }); const d = await r.json(); d.success ? (studentLogin(d.student, d.token), toast.success(`Welcome, ${d.student.name}!`)) : toast.error(d.message); } catch { toast.error('Error'); }
    setLd(false);
  };
  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 page-transition">
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-50 via-white to-teal-50" />
      <div className="relative w-full max-w-md">
        <div className="modern-card rounded-2xl p-8 shadow-xl shadow-gray-200/50">
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-emerald-500/20">
              <GraduationCap className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-2xl font-black text-gray-900">{tr.studentLogin}</h1>
            <p className="text-gray-400 text-xs mt-1">Shrinath Chanakya Coaching Classes</p>
          </div>
          <form onSubmit={go} className="space-y-4">
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{tr.stuId}</Label>
              <div className="relative mt-1"><User className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-300" /><Input required value={f.student_id} onChange={e => setF({ ...f, student_id: e.target.value })} className="pl-10 rounded-xl h-11" placeholder="STU001" /></div>
            </div>
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{tr.password}</Label>
              <div className="relative mt-1"><Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-300" /><Input required type={show ? 'text' : 'password'} value={f.password} onChange={e => setF({ ...f, password: e.target.value })} className="pl-10 pr-10 rounded-xl h-11" placeholder="••••••••" />
                <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-300 hover:text-gray-500">{show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button>
              </div>
            </div>
            <Button type="submit" disabled={ld} className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl h-11 font-bold text-sm shadow-lg shadow-emerald-500/20">
              {ld ? '...' : <><KeyRound className="h-4 w-4 mr-2" />{tr.login}</>}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════ ADMIN LOGIN ═══════════════════════ */
function AdminLoginPage() {
  const { adminLogin } = useAppStore();
  const [f, setF] = useState({ username: '', password: '' });
  const [show, setShow] = useState(false);
  const [ld, setLd] = useState(false);
  const go = async (e: React.FormEvent) => {
    e.preventDefault(); setLd(true);
    try { const r = await fetch('/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(f) }); const d = await r.json(); d.success ? (adminLogin(d.token), toast.success('Welcome, Admin!')) : toast.error(d.message); } catch { toast.error('Error'); }
    setLd(false);
  };
  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 page-transition">
      <div className="absolute inset-0 bg-gradient-to-br from-gray-50 via-white to-gray-50" />
      <div className="relative w-full max-w-md">
        <div className="modern-card rounded-2xl p-8 shadow-xl shadow-gray-200/50">
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-gray-800/20"><Shield className="h-8 w-8 text-white" /></div>
            <h1 className="text-2xl font-black text-gray-900">Admin Login</h1>
            <p className="text-gray-400 text-xs mt-1">Authorized Personnel Only</p>
          </div>
          <form onSubmit={go} className="space-y-4">
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Username</Label><Input required value={f.username} onChange={e => setF({ ...f, username: e.target.value })} className="mt-1 rounded-xl h-11" placeholder="admin" /></div>
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Password</Label>
              <div className="relative mt-1"><Input required type={show ? 'text' : 'password'} value={f.password} onChange={e => setF({ ...f, password: e.target.value })} className="pr-10 rounded-xl h-11" placeholder="••••••••" />
                <button type="button" onClick={() => setShow(!show)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-300">{show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button>
              </div>
            </div>
            <Button type="submit" disabled={ld} className="w-full bg-gradient-to-r from-gray-800 to-gray-900 hover:from-gray-900 hover:to-black text-white rounded-xl h-11 font-bold text-sm shadow-lg">
              {ld ? '...' : <><Shield className="h-4 w-4 mr-2" />Login</>}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════ STUDENT DASHBOARD ═══════════════════════ */
function StudentDash() {
  const { lang, student, setCurrentPage, setCurrentTest } = useAppStore();
  const tr = T[lang];
  const [tests, setTests] = useState<Test[]>([]);
  const [results, setResults] = useState<ExamResult[]>([]);
  const [ld, setLd] = useState(true);
  useEffect(() => {
    if (!student) return;
    (async () => {
      try {
        const [t, r] = await Promise.all([fetch('/api/tests'), fetch(`/api/results/student/${student.id}`)]);
        const td = await t.json(), rd = await r.json();
        if (td.success) setTests(td.tests.filter((x: Test) => x.class_for === student?.class || x.class_for === 'All'));
        if (rd.success) setResults(rd.results);
      } catch { /* */ }
      setLd(false);
    })();
  }, [student]);
  const start = async (test: Test) => {
    if (results.some(r => r.test?.id === test.id)) return toast.error(tr.taken);
    try {
      const r = await fetch(`/api/tests/${test.id}`); const d = await r.json();
      if (d.success) { setCurrentTest(d.test, d.test.questions); useAppStore.getState().clearExamState(); setCurrentTest(d.test, d.test.questions); setCurrentPage('student-exam'); }
    } catch { toast.error('Error'); }
  };
  if (!student) return <div className="text-center py-20 text-gray-400">Please login</div>;
  const ini = student.name.split(' ').map(w => w[0]).join('').toUpperCase();
  return (
    <div className="max-w-6xl mx-auto px-4 py-8 page-transition">
      {/* Profile */}
      <div className="modern-card rounded-2xl p-6 md:p-8 mb-8 bg-gradient-to-r from-emerald-600 to-teal-600 text-white overflow-hidden relative">
        <div className="absolute inset-0 opacity-[0.05]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '30px 30px' }} />
        <div className="relative flex flex-col sm:flex-row items-center gap-5">
          <Avatar className="h-20 w-20 border-4 border-white/20 shadow-lg"><AvatarFallback className="text-2xl font-black bg-white/20 text-white">{ini}</AvatarFallback></Avatar>
          <div className="text-center sm:text-left">
            <h1 className="text-2xl font-black">{tr.welcome}, {student.name}!</h1>
            <div className="flex flex-wrap gap-2 mt-2.5 justify-center sm:justify-start">
              {[`ID: ${student.student_id}`, `${tr.roll}: ${student.roll_number}`, `${tr.yourCls}: ${student.class}`].map((b, i) => (
                <Badge key={i} className="bg-white/15 text-white border-white/10 text-[11px] font-medium">{b}</Badge>
              ))}
            </div>
          </div>
        </div>
      </div>
      {/* Tests */}
      <div className="mb-8">
        <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2"><FileText className="h-5 w-5 text-emerald-500" />{tr.availTests}</h2>
        {ld ? <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">{[1, 2].map(i => <div key={i} className="modern-card rounded-2xl p-6 animate-pulse"><div className="h-4 bg-gray-100 rounded w-3/4 mb-3" /><div className="h-3 bg-gray-100 rounded w-1/2" /></div>)}</div> :
          tests.length === 0 ? <div className="modern-card rounded-2xl p-12 text-center text-gray-300"><FileText className="h-12 w-12 mx-auto mb-3" />{tr.noTests}</div> :
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {tests.map(test => {
              const done = results.some(r => r.test?.id === test.id);
              return (
                <div key={test.id} className="modern-card rounded-2xl overflow-hidden">
                  <div className="h-1.5 bg-gradient-to-r from-emerald-500 to-teal-500" />
                  <div className="p-5">
                    <h3 className="font-bold text-gray-900 mb-1 text-sm leading-snug">{test.title}</h3>
                    <p className="text-gray-400 text-xs mb-3 line-clamp-1">{test.description}</p>
                    <div className="flex flex-wrap gap-1.5 mb-4">
                      {[`${test.duration}m`, `${test.total_questions}Q`, `${test.marks_per_question * test.total_questions}M`].map((b, i) => (
                        <Badge key={i} variant="outline" className="text-[10px] border-gray-200 text-gray-500 font-medium">{b}</Badge>
                      ))}
                    </div>
                    {done ? <Button variant="outline" disabled className="w-full rounded-xl text-xs border-amber-200 text-amber-500 h-10">{tr.taken}</Button> :
                      <Button onClick={() => start(test)} className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl h-10 text-xs font-semibold shadow-md shadow-emerald-500/20">{tr.startTest}</Button>}
                  </div>
                </div>
              );
            })}
          </div>
        }
      </div>
      {/* Results */}
      <div>
        <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2"><Trophy className="h-5 w-5 text-amber-500" />{tr.prevResults}</h2>
        {results.length === 0 ? <div className="modern-card rounded-2xl p-12 text-center text-gray-300"><Trophy className="h-12 w-12 mx-auto mb-3" />{tr.noRes}</div> :
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {results.map((r, i) => (
              <div key={i} className="modern-card rounded-2xl p-5">
                <h3 className="font-semibold text-gray-900 text-xs mb-3 line-clamp-1">{r.test?.title || r.test_title}</h3>
                <div className="flex items-center gap-4 mb-3">
                  <div className="text-center"><div className={`text-2xl font-black ${r.percentage >= 60 ? 'text-emerald-600' : 'text-red-500'}`}>{r.percentage}%</div><div className="text-[10px] text-gray-400">{tr.pct}</div></div>
                  <div className="h-10 w-px bg-gray-100" />
                  <div className="text-center"><div className="text-2xl font-black text-gray-900">{r.score}</div><div className="text-[10px] text-gray-400">/{r.totalMarks}</div></div>
                </div>
                <Button size="sm" variant="outline" className="w-full rounded-xl text-xs border-emerald-200 text-emerald-600 h-9 font-semibold" onClick={() => { useAppStore.getState().setCurrentResult(r); setCurrentPage('student-result'); }}>{tr.viewRes}</Button>
              </div>
            ))}
          </div>
        }
      </div>
    </div>
  );
}

/* ═══════════════════════ EXAM PAGE ═══════════════════════ */
function ExamPage() {
  const { lang, currentTest, currentQuestions, student, setCurrentPage, setCurrentResult, setExamAnswer } = useAppStore();
  const tr = T[lang];
  const [phase, setPhase] = useState<'instr' | 'count' | 'active' | 'done'>('instr');
  const [violations, setViolations] = useState(0);
  const [warn, setWarn] = useState('');
  const [time, setTime] = useState(0);
  const [cq, setCq] = useState(0);
  const [cd, setCd] = useState(3);
  const [fsLost, setFsLost] = useState(false);
  const [answers, setAnswers] = useState<(string | null)[]>([]);
  const ansRef = useRef<(string | null)[]>([]);
  const vRef = useRef(0);
  const phRef = useRef(phase);
  const subRef = useRef(false);
  const fsReadyRef = useRef(false);
  const prevQCountRef = useRef(0);

  useEffect(() => { phRef.current = phase; }, [phase]);
  useEffect(() => { vRef.current = violations; }, [violations]);

  // Sync answers when questions change
  useEffect(() => {
    if (currentQuestions.length > 0 && prevQCountRef.current !== currentQuestions.length) {
      prevQCountRef.current = currentQuestions.length;
      const a = new Array(currentQuestions.length).fill(null);
      ansRef.current = a;
      setTimeout(() => setAnswers([...a]), 0);
    }
  }, [currentQuestions.length]);

  const selectAnswer = (idx: number, val: string | null) => {
    ansRef.current[idx] = val;
    setAnswers(prev => {
      const a = [...prev];
      a[idx] = val;
      ansRef.current = a;
      return a;
    });
    setExamAnswer(idx, val);
  };

  const submitExam = useCallback(async (reason: string) => {
    if (subRef.current) return; subRef.current = true;
    try {
      const r = await fetch('/api/exam/submit', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ student_id: student?.id, test_id: currentTest?.id, answers: ansRef.current }) });
      const d = await r.json();
      if (d.success) { setCurrentResult(d.result); toast.success(reason || tr.subOk); setPhase('done'); } else { toast.error(d.message); setPhase('done'); }
    } catch { toast.error('Error'); setPhase('done'); }
  }, [student, currentTest, setCurrentResult, tr]);

  const startFS = async () => {
    try {
      const el = document.documentElement as HTMLElement & { requestFullscreen?: () => Promise<void>; webkitRequestFullscreen?: () => Promise<void> };
      if (el.requestFullscreen) await el.requestFullscreen();
      else if (el.webkitRequestFullscreen) await el.webkitRequestFullscreen();
      await new Promise(r => setTimeout(r, 800));
      fsReadyRef.current = true;
      setPhase('count'); setCd(3);
    } catch {
      fsReadyRef.current = true;
      setPhase('count'); setCd(3);
    }
  };

  useEffect(() => {
    if (phase !== 'count') return;
    if (cd <= 0) {
      // Use setTimeout to avoid calling setState synchronously in effect
      const t = setTimeout(() => {
        setPhase('active');
        if (currentTest) setTime(currentTest.duration * 60);
      }, 0);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setCd(c => c - 1), 1000);
    return () => clearTimeout(t);
  }, [phase, cd, currentTest]);
  useEffect(() => { if (phase !== 'active' || time <= 0) return; const t = setInterval(() => { setTime(t => { if (t <= 1) { submitExam(tr.timeUp); return 0; } return t - 1; }); }, 1000); return () => clearInterval(t); }, [phase, time, submitExam, tr]);
  useEffect(() => { if (phase !== 'active') return; const h = (e: KeyboardEvent) => { if (e.ctrlKey && 'cvxupa'.includes(e.key.toLowerCase())) e.preventDefault(); if (e.key === 'F12') e.preventDefault(); if (e.ctrlKey && e.shiftKey && 'ij'.includes(e.key.toLowerCase())) e.preventDefault(); }; document.addEventListener('keydown', h); return () => document.removeEventListener('keydown', h); }, [phase]);
  useEffect(() => { if (phase !== 'active') return; const h = (e: MouseEvent) => e.preventDefault(); document.addEventListener('contextmenu', h); return () => document.removeEventListener('contextmenu', h); }, [phase]);
  useEffect(() => { if (phase !== 'active') return; const h = () => { if (document.hidden) { setWarn('⚠️ Tab switch detected!'); const v = vRef.current + 1; vRef.current = v; setViolations(v); if (v >= 3) submitExam(tr.autoSub); } }; document.addEventListener('visibilitychange', h); return () => document.removeEventListener('visibilitychange', h); }, [phase, submitExam, tr]);
  useEffect(() => { if (!fsReadyRef.current || phase !== 'active') return; const h = () => { setTimeout(() => { if (phRef.current !== 'active') return; const fs = !!(document.fullscreenElement || (document as unknown as Record<string, Element>).webkitFullscreenElement); if (!fs) { setFsLost(true); setTimeout(() => { const still = !(document.fullscreenElement || (document as unknown as Record<string, Element>).webkitFullscreenElement); if (still && phRef.current === 'active') { const v = vRef.current + 1; vRef.current = v; setViolations(v); setWarn(`⚠️ Violation ${v}/3`); if (v >= 3) submitExam(tr.autoSub); } setFsLost(false); }, 5000); } }, 500); }; document.addEventListener('fullscreenchange', h); document.addEventListener('webkitfullscreenchange', h); return () => { document.removeEventListener('fullscreenchange', h); document.removeEventListener('webkitfullscreenchange', h); }; }, [phase, submitExam, tr]);
  const reFS = async () => { try { const el = document.documentElement as HTMLElement & { requestFullscreen?: () => Promise<void>; webkitRequestFullscreen?: () => Promise<void> }; if (el.requestFullscreen) await el.requestFullscreen(); else if (el.webkitRequestFullscreen) await el.webkitRequestFullscreen(); setFsLost(false); } catch { /* */ } };
  const fmt = (s: number) => `${Math.floor(s / 60).toString().padStart(2, '0')}:${(s % 60).toString().padStart(2, '0')}`;
  useEffect(() => { if (phase === 'done') setTimeout(() => setCurrentPage('student-result'), 1500); }, [phase, setCurrentPage]);

  if (!currentTest || !student) return <div className="text-center py-20"><p className="text-gray-400">No test</p><Button onClick={() => setCurrentPage('student-dashboard')} className="mt-4">Back</Button></div>;

  // INSTRUCTIONS
  if (phase === 'instr') return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 bg-gradient-to-br from-gray-50 to-white page-transition">
      <div className="w-full max-w-lg">
        <div className="modern-card rounded-2xl p-8 shadow-xl shadow-gray-200/50">
          <div className="text-center mb-6">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-amber-500/20"><AlertTriangle className="h-7 w-7 text-white" /></div>
            <h1 className="text-xl font-black text-gray-900">{tr.instr}</h1>
            <p className="text-gray-400 text-xs mt-1">{currentTest.title}</p>
          </div>
          <div className="bg-gray-50 rounded-xl p-4 space-y-2.5 text-sm mb-6">
            {[{ ic: Monitor, t: 'Fullscreen mode required during exam', c: 'text-emerald-600' }, { ic: Ban, t: 'Right-click, Copy/Paste, DevTools disabled', c: 'text-red-500' }, { ic: AlertOctagon, t: 'Tab switching = violation', c: 'text-amber-500' }, { ic: XCircle, t: '3 violations = Auto-submit', c: 'text-red-600' }].map((r, i) => (
              <div key={i} className="flex items-start gap-2.5"><r.ic className={`h-4 w-4 mt-0.5 shrink-0 ${r.c}`} /><span className="text-gray-600">{r.t}</span></div>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-3 mb-6">
            {[{ n: `${currentTest.duration}m`, l: 'Duration', ic: Clock }, { n: `${currentTest.total_questions}`, l: 'Questions', ic: BookOpen }, { n: `${currentTest.marks_per_question * currentTest.total_questions}`, l: 'Marks', ic: Star }].map((s, i) => (
              <div key={i} className="bg-emerald-50 rounded-xl p-3 text-center"><s.ic className="h-4 w-4 text-emerald-500 mx-auto mb-1" /><div className="text-lg font-black text-gray-900">{s.n}</div><div className="text-[10px] text-gray-400">{s.l}</div></div>
            ))}
          </div>
          <Button onClick={startFS} className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl h-12 font-bold text-sm shadow-lg shadow-emerald-500/20"><Fullscreen className="h-4 w-4 mr-2" />{tr.enterFS}</Button>
        </div>
      </div>
    </div>
  );

  // COUNTDOWN
  if (phase === 'count') return (
    <div className="fixed inset-0 bg-gradient-to-br from-emerald-800 to-teal-900 flex items-center justify-center z-50">
      <div className="text-center text-white"><div className="text-[120px] font-black leading-none mb-4">{cd}</div><div className="text-xl font-semibold text-emerald-200">Get Ready!</div></div>
    </div>
  );

  // DONE
  if (phase === 'done') return (
    <div className="fixed inset-0 bg-white flex items-center justify-center z-50">
      <div className="text-center"><CheckCircle className="h-20 w-20 text-emerald-500 mx-auto mb-4" /><h2 className="text-xl font-black text-gray-900 mb-1">{tr.subOk}</h2><p className="text-gray-400 text-sm">Loading results...</p></div>
    </div>
  );

  const q = currentQuestions[cq];
  if (!q) return null;

  // ACTIVE EXAM
  return (
    <div className="fixed inset-0 bg-[#f8fafb] flex flex-col z-50">
      {warn && <div className="bg-red-600 text-white text-center py-1.5 px-4 text-xs font-bold animate-pulse">{warn}</div>}
      {fsLost && <div className="bg-amber-500 text-white text-center py-1.5 px-4 flex items-center justify-center gap-2"><span className="text-xs font-bold">{tr.fsWarn}</span><Button size="sm" variant="secondary" onClick={reFS} className="h-6 text-[10px]">Re-enter</Button></div>}
      <div className="bg-white border-b px-4 py-2.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2 min-w-0"><h2 className="font-bold text-gray-900 text-xs truncate max-w-[180px] sm:max-w-none">{currentTest.title}</h2><Badge variant="outline" className="text-[10px]">Q{cq + 1}/{currentQuestions.length}</Badge></div>
        <div className="flex items-center gap-2">
          {violations > 0 && <Badge variant="destructive" className="text-[10px]"><AlertTriangle className="h-3 w-3 mr-0.5" />{violations}/3</Badge>}
          <div className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-mono font-bold ${time < 300 ? 'bg-red-50 text-red-600' : 'bg-emerald-50 text-emerald-700'}`}><Timer className="h-3.5 w-3.5" />{fmt(time)}</div>
        </div>
      </div>
      <div className="w-full bg-gray-100 h-0.5 shrink-0"><div className="bg-gradient-to-r from-emerald-500 to-teal-500 h-full transition-all" style={{ width: `${((cq + 1) / currentQuestions.length) * 100}%` }} /></div>
      <div className="flex-1 overflow-auto p-4">
        <div className="max-w-2xl mx-auto">
          <div className="modern-card rounded-2xl p-6">
            <div className="flex items-start gap-3 mb-5"><span className="text-xs font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md shrink-0">Q{cq + 1}</span><h2 className="font-semibold text-gray-900 text-sm leading-relaxed">{q.question_text}</h2></div>
            <div className="space-y-2.5">
              {(['A', 'B', 'C', 'D'] as const).map(o => {
                const txt = q[`option_${o.toLowerCase()}` as keyof Question] as string;
                const sel = answers[cq] === o;
                return (
                  <button key={o} onClick={() => selectAnswer(cq, o)}
                    className={`w-full text-left p-3.5 rounded-xl border-2 transition-all flex items-center gap-3 text-sm ${sel ? 'border-emerald-500 bg-emerald-50 shadow-sm' : 'border-gray-100 hover:border-emerald-200 bg-white'}`}>
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 transition-colors ${sel ? 'bg-emerald-600 text-white shadow-md' : 'bg-gray-50 text-gray-500'}`}>{o}</div>
                    <span className="text-gray-700">{txt}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
      <div className="bg-white border-t px-4 py-2.5 shrink-0">
        <div className="max-w-2xl mx-auto">
          <div className="flex flex-wrap gap-1 mb-2.5 justify-center">{currentQuestions.map((_, i) => (
            <button key={i} onClick={() => setCq(i)} className={`w-7 h-7 rounded-lg text-[10px] font-bold transition-all ${i === cq ? 'bg-emerald-600 text-white shadow-md' : answers[i] ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-50 text-gray-400'}`}>{i + 1}</button>
          ))}</div>
          <div className="flex items-center justify-between">
            <Button variant="ghost" size="sm" onClick={() => setCq(Math.max(0, cq - 1))} disabled={cq === 0} className="rounded-lg text-xs"><ArrowLeft className="h-3.5 w-3.5 mr-1" />Prev</Button>
            <Button onClick={() => { const u = answers.filter(a => a === null).length; if (u > 0 && !confirm(`${u} unanswered. Submit?`)) return; submitExam(tr.subOk); }} className="bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700 text-white rounded-lg h-9 text-xs font-semibold"><CheckCheck className="h-3.5 w-3.5 mr-1" />Submit</Button>
            <Button variant="ghost" size="sm" onClick={() => setCq(Math.min(currentQuestions.length - 1, cq + 1))} disabled={cq === currentQuestions.length - 1} className="rounded-lg text-xs">Next<ArrowRight className="h-3.5 w-3.5 ml-1" /></Button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════ RESULT PAGE ═══════════════════════ */
function ResultPage() {
  const { lang, currentResult, setCurrentPage } = useAppStore();
  const tr = T[lang];
  if (!currentResult) return <div className="text-center py-20 text-gray-400">No result</div>;
  const r = currentResult;
  const circ = 2 * Math.PI * 54;
  const off = circ - (r.percentage / 100) * circ;
  const col = r.percentage >= 80 ? '#059669' : r.percentage >= 60 ? '#d97706' : '#dc2626';
  return (
    <div className="max-w-4xl mx-auto px-4 py-8 page-transition">
      <div className="modern-card rounded-2xl p-6 md:p-10 mb-6">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="relative w-36 h-36 shrink-0">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120"><circle cx="60" cy="60" r="54" stroke="#f3f4f6" strokeWidth="10" fill="none" /><circle cx="60" cy="60" r="54" stroke={col} strokeWidth="10" fill="none" strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={off} /></svg>
            <div className="absolute inset-0 flex items-center justify-center"><div className="text-center"><div className="text-3xl font-black" style={{ color: col }}>{r.percentage}%</div></div></div>
          </div>
          <div className="flex-1 text-center md:text-left">
            <h2 className="text-lg font-bold text-gray-900 mb-1">{r.test_title}</h2>
            <p className="text-gray-400 text-xs mb-4">{new Date(r.submitted_at).toLocaleString()}</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[{ n: r.score, l: tr.score, c: 'text-emerald-700 bg-emerald-50' }, { n: r.totalMarks, l: tr.total, c: 'text-gray-700 bg-gray-50' }, { n: r.total_questions, l: tr.q, c: 'text-gray-700 bg-gray-50' }, { n: r.detailed_answers?.filter((a: DetailedAnswer) => a.is_correct).length || 0, l: tr.correct, c: 'text-emerald-700 bg-emerald-50' }].map((s, i) => (
                <div key={i} className={`rounded-xl p-3 text-center ${s.c}`}><div className="text-xl font-black">{s.n}</div><div className="text-[10px] opacity-60 font-medium">{s.l}</div></div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="flex gap-2 mb-6">
        <Button variant="outline" onClick={() => setCurrentPage('student-dashboard')} className="rounded-xl text-xs border-gray-200"><ArrowLeft className="h-3.5 w-3.5 mr-1" />{tr.back}</Button>
        <Button variant="outline" onClick={() => window.print()} className="rounded-xl text-xs border-gray-200"><Printer className="h-3.5 w-3.5 mr-1" />{tr.print}</Button>
      </div>
      <div className="modern-card rounded-2xl overflow-hidden">
        <div className="p-5 border-b"><h3 className="font-bold text-gray-900 text-sm">{tr.detailed}</h3></div>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow className="bg-gray-50/80"><TableHead className="w-10 text-[10px] font-bold">{tr.qNo}</TableHead><TableHead className="min-w-[180px] text-[10px] font-bold">{tr.q}</TableHead><TableHead className="text-[10px] font-bold">{tr.yourAns}</TableHead><TableHead className="text-[10px] font-bold">{tr.cAns}</TableHead><TableHead className="w-20 text-[10px] font-bold">{tr.status}</TableHead><TableHead className="w-14 text-[10px] font-bold">{tr.marks}</TableHead></TableRow></TableHeader>
            <TableBody>{r.detailed_answers?.map((a: DetailedAnswer, i: number) => (
              <TableRow key={i} className={!a.is_correct ? 'bg-red-50/40' : ''}>
                <TableCell className="font-bold text-xs">{i + 1}</TableCell>
                <TableCell className="text-xs max-w-[220px] truncate">{a.question_text}</TableCell>
                <TableCell className={`text-xs font-semibold ${a.student_answer ? (a.is_correct ? 'text-emerald-600' : 'text-red-500') : 'text-gray-300'}`}>{a.student_answer ? `${a.student_answer}` : '-'}</TableCell>
                <TableCell className="text-xs font-semibold text-emerald-600">{a.correct_answer}</TableCell>
                <TableCell>{a.is_correct ? <Badge className="bg-emerald-100 text-emerald-700 text-[10px]"><CheckCircle className="h-3 w-3 mr-0.5" /></Badge> : <Badge className="bg-red-100 text-red-600 text-[10px]"><XCircle className="h-3 w-3 mr-0.5" /></Badge>}</TableCell>
                <TableCell className="font-bold text-xs">{a.marks_obtained}</TableCell>
              </TableRow>
            ))}</TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════ ADMIN DASHBOARD ═══════════════════════ */
function AdminDash() {
  const { setCurrentPage } = useAppStore();
  const [tests, setTests] = useState<Test[]>([]);
  const [stus, setStus] = useState<{ id: number }[]>([]);
  const [res, setRes] = useState<{ id: number }[]>([]);
  const [ld, setLd] = useState(true);
  useEffect(() => {
    (async () => {
      try {
        const [t, s] = await Promise.all([fetch('/api/tests'), fetch('/api/students')]);
        const td = await t.json(), sd = await s.json();
        if (td.success) { setTests(td.tests); setRes(Array(td.tests.reduce((a: number, x: Test) => a + (x._count?.results || 0), 0)).fill({ id: 0 })); }
        if (sd.success) setStus(sd.students);
      } catch { /* */ }
      setLd(false);
    })();
  }, []);
  const del = async (id: number) => { if (!confirm('Delete test?')) return; try { await fetch(`/api/tests/${id}`, { method: 'DELETE' }); setTests(tests.filter(t => t.id !== id)); toast.success('Deleted'); } catch { toast.error('Error'); } };
  const statCards = [
    { n: tests.length, l: 'Total Tests', ic: FileText, c: 'from-emerald-500 to-teal-600', sc: 'shadow-emerald-500/20' },
    { n: stus.length, l: 'Students', ic: Users, c: 'from-amber-500 to-orange-600', sc: 'shadow-amber-500/20' },
    { n: res.length, l: 'Results', ic: Trophy, c: 'from-violet-500 to-purple-600', sc: 'shadow-violet-500/20' },
  ];
  return (
    <div className="max-w-7xl mx-auto px-4 py-8 page-transition">
      <div className="flex items-center justify-between mb-8">
        <div><h1 className="text-2xl font-black text-gray-900 tracking-tight">Admin Dashboard</h1><p className="text-gray-400 text-xs mt-0.5">Manage tests, students & results</p></div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        {statCards.map((s, i) => (
          <div key={i} className="modern-card rounded-2xl p-5 flex items-center gap-4">
            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${s.c} flex items-center justify-center shadow-lg ${s.sc}`}><s.ic className="h-6 w-6 text-white" /></div>
            <div><div className="text-2xl font-black text-gray-900">{s.n}</div><div className="text-xs text-gray-400 font-medium">{s.l}</div></div>
          </div>
        ))}
      </div>
      <div className="flex flex-wrap gap-2 mb-6">
        {[{ l: 'Add Test', p: 'admin-add-test', ic: Plus }, { l: 'Upload Test', p: 'admin-upload-test', ic: Upload }, { l: 'Add Student', p: 'admin-add-student', ic: Plus }, { l: 'Students', p: 'admin-students', ic: Users }].map((b, i) => (
          <Button key={i} variant="outline" onClick={() => setCurrentPage(b.p as never)} className="rounded-xl text-xs font-medium border-gray-200 hover:border-emerald-200 hover:text-emerald-700 h-9"><b.ic className="h-3.5 w-3.5 mr-1.5" />{b.l}</Button>
        ))}
      </div>
      <div className="modern-card rounded-2xl overflow-hidden">
        <div className="p-5 border-b"><h2 className="font-bold text-gray-900 text-sm">All Tests</h2></div>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow className="bg-gray-50/80"><TableHead className="text-[10px] font-bold">ID</TableHead><TableHead className="text-[10px] font-bold">Title</TableHead><TableHead className="text-[10px] font-bold">Class</TableHead><TableHead className="text-[10px] font-bold">Duration</TableHead><TableHead className="text-[10px] font-bold">Questions</TableHead><TableHead className="text-[10px] font-bold text-right">Actions</TableHead></TableRow></TableHeader>
            <TableBody>{ld ? <TableRow><TableCell colSpan={6} className="py-8 text-center text-gray-300 text-xs">Loading...</TableCell></TableRow> :
              tests.length === 0 ? <TableRow><TableCell colSpan={6} className="py-8 text-center text-gray-300 text-xs">No tests</TableCell></TableRow> :
              tests.map(t => (
                <TableRow key={t.id}>
                  <TableCell className="font-mono text-xs font-bold text-gray-500">{t.id}</TableCell>
                  <TableCell className="text-xs font-semibold max-w-[250px] truncate">{t.title}</TableCell>
                  <TableCell><Badge variant="outline" className="text-[10px] border-gray-200">{t.class_for}</Badge></TableCell>
                  <TableCell className="text-xs text-gray-500">{t.duration}m</TableCell>
                  <TableCell className="text-xs text-gray-500">{t._count?.questions || t.total_questions}</TableCell>
                  <TableCell className="text-right">
                    <Button size="sm" variant="ghost" onClick={() => { useAppStore.getState().setEditTest(t); setCurrentPage('admin-edit-test'); }} className="h-7 w-7 p-0 rounded-lg text-gray-400 hover:text-emerald-600"><Edit className="h-3.5 w-3.5" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => del(t.id)} className="h-7 w-7 p-0 rounded-lg text-gray-400 hover:text-red-500"><Trash2 className="h-3.5 w-3.5" /></Button>
                  </TableCell>
                </TableRow>
              ))}</TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════ ADD TEST ═══════════════════════ */
function AddTestPage() {
  const { setCurrentPage } = useAppStore();
  const eq = { question_text: '', option_a: '', option_b: '', option_c: '', option_d: '', correct_answer: 'A' };
  const [f, setF] = useState({ title: '', description: '', duration: 30, marks_per_question: 4, class_for: '10th' });
  const [qs, setQs] = useState([{ ...eq }]);
  const [ld, setLd] = useState(false);
  const uq = (i: number, k: string, v: string) => { const n = [...qs]; n[i] = { ...n[i], [k]: v }; setQs(n); };
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!f.title || qs.some(q => !q.question_text || !q.option_a || !q.option_b || !q.option_c || !q.option_d)) return toast.error('Fill all fields');
    setLd(true);
    try { const r = await fetch('/api/tests', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...f, questions: qs }) }); const d = await r.json(); d.success ? (toast.success('Test created!'), setCurrentPage('admin-dashboard')) : toast.error(d.message); } catch { toast.error('Error'); }
    setLd(false);
  };
  return (
    <div className="max-w-4xl mx-auto px-4 py-8 page-transition">
      <div className="flex items-center gap-3 mb-6"><Button variant="ghost" size="icon" onClick={() => setCurrentPage('admin-dashboard')} className="rounded-xl"><ArrowLeft className="h-4 w-4" /></Button><h1 className="text-xl font-black text-gray-900">Add Test</h1></div>
      <form onSubmit={submit} className="space-y-5">
        <div className="modern-card rounded-2xl p-6 space-y-4">
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Title</Label><Input required value={f.title} onChange={e => setF({ ...f, title: e.target.value })} className="mt-1 rounded-xl h-11" /></div>
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Description</Label><Textarea value={f.description} onChange={e => setF({ ...f, description: e.target.value })} className="mt-1 rounded-xl" rows={2} /></div>
          <div className="grid grid-cols-3 gap-4">
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Duration (min)</Label><Input type="number" min={1} value={f.duration} onChange={e => setF({ ...f, duration: +e.target.value || 30 })} className="mt-1 rounded-xl h-11" /></div>
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Marks/Q</Label><Input type="number" min={1} value={f.marks_per_question} onChange={e => setF({ ...f, marks_per_question: +e.target.value || 4 })} className="mt-1 rounded-xl h-11" /></div>
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Class</Label><Select value={f.class_for} onValueChange={v => setF({ ...f, class_for: v })}><SelectTrigger className="mt-1 rounded-xl h-11"><SelectValue /></SelectTrigger><SelectContent>{CLS.map(c => <SelectItem key={c} value={c}>Class {c}</SelectItem>)}</SelectContent></Select></div>
          </div>
        </div>
        {qs.map((q, i) => (
          <div key={i} className="modern-card rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3"><span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Question {i + 1}</span>{qs.length > 1 && <Button type="button" variant="ghost" size="icon" onClick={() => setQs(qs.filter((_, x) => x !== i))} className="h-7 w-7 rounded-lg text-gray-300 hover:text-red-500"><Trash2 className="h-3.5 w-3.5" /></Button>}</div>
            <div className="space-y-3">
              <Input required value={q.question_text} onChange={e => uq(i, 'question_text', e.target.value)} placeholder="Question text" className="rounded-xl h-10 text-sm" />
              <div className="grid grid-cols-2 gap-2">{['a', 'b', 'c', 'd'].map(o => <Input key={o} required value={q[`option_${o}`]} onChange={e => uq(i, `option_${o}`, e.target.value)} placeholder={o.toUpperCase()} className="rounded-xl h-10 text-sm" />)}</div>
              <div className="w-32"><Select value={q.correct_answer} onValueChange={v => uq(i, 'correct_answer', v)}><SelectTrigger className="rounded-xl h-10 text-xs"><SelectValue /></SelectTrigger><SelectContent>{['A', 'B', 'C', 'D'].map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent></Select></div>
            </div>
          </div>
        ))}
        <div className="flex gap-2">
          <Button type="button" variant="outline" onClick={() => setQs([...qs, { ...eq }])} className="rounded-xl text-xs border-gray-200"><Plus className="h-3.5 w-3.5 mr-1" />Add Question</Button>
          <div className="flex-1" />
          <Button type="button" variant="outline" onClick={() => setCurrentPage('admin-dashboard')} className="rounded-xl text-xs">{T.en.cancel}</Button>
          <Button type="submit" disabled={ld} className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl text-xs font-semibold px-6 shadow-lg shadow-emerald-500/20">{ld ? '...' : 'Create Test'}</Button>
        </div>
      </form>
    </div>
  );
}

/* ═══════════════════════ EDIT TEST ═══════════════════════ */
function EditTestPage() {
  const { editTest, setCurrentPage } = useAppStore();
  const [f, setF] = useState({ title: editTest?.title || '', description: editTest?.description || '', duration: editTest?.duration || 30, marks_per_question: editTest?.marks_per_question || 4, class_for: editTest?.class_for || '10th' });
  const [qs, setQs] = useState<Array<Record<string, string>>>([]);
  const [ld, setLd] = useState(false);
  useEffect(() => { if (!editTest) return; (async () => { try { const r = await fetch(`/api/tests/${editTest.id}`); const d = await r.json(); if (d.success?.questions) setQs(d.test.questions.map((q: Question) => ({ question_text: q.question_text, option_a: q.option_a, option_b: q.option_b, option_c: q.option_c, option_d: q.option_d, correct_answer: q.correct_answer }))); } catch { /* */ } })(); }, [editTest]);
  if (!editTest) return <div className="text-center py-20"><p className="text-gray-400">No test</p><Button onClick={() => setCurrentPage('admin-dashboard')} className="mt-4">Back</Button></div>;
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setLd(true);
    try { const r = await fetch(`/api/tests/${editTest.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(f) }); r.ok ? (toast.success('Updated'), setCurrentPage('admin-dashboard')) : toast.error('Error'); } catch { toast.error('Error'); }
    setLd(false);
  };
  return (
    <div className="max-w-4xl mx-auto px-4 py-8 page-transition">
      <div className="flex items-center gap-3 mb-6"><Button variant="ghost" size="icon" onClick={() => setCurrentPage('admin-dashboard')} className="rounded-xl"><ArrowLeft className="h-4 w-4" /></Button><h1 className="text-xl font-black text-gray-900">Edit Test #{editTest.id}</h1></div>
      <form onSubmit={submit} className="space-y-5">
        <div className="modern-card rounded-2xl p-6 space-y-4">
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Title</Label><Input required value={f.title} onChange={e => setF({ ...f, title: e.target.value })} className="mt-1 rounded-xl h-11" /></div>
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Description</Label><Textarea value={f.description} onChange={e => setF({ ...f, description: e.target.value })} className="mt-1 rounded-xl" rows={2} /></div>
          <div className="grid grid-cols-3 gap-4">
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Duration</Label><Input type="number" min={1} value={f.duration} onChange={e => setF({ ...f, duration: +e.target.value || 30 })} className="mt-1 rounded-xl h-11" /></div>
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Marks/Q</Label><Input type="number" min={1} value={f.marks_per_question} onChange={e => setF({ ...f, marks_per_question: +e.target.value || 4 })} className="mt-1 rounded-xl h-11" /></div>
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Class</Label><Select value={f.class_for} onValueChange={v => setF({ ...f, class_for: v })}><SelectTrigger className="mt-1 rounded-xl h-11"><SelectValue /></SelectTrigger><SelectContent>{CLS.map(c => <SelectItem key={c} value={c}>Class {c}</SelectItem>)}</SelectContent></Select></div>
          </div>
        </div>
        <div className="modern-card rounded-2xl p-5">
          <h3 className="font-bold text-gray-900 text-sm mb-4">Questions ({qs.length})</h3>
          <ScrollArea className="max-h-80">
            <div className="space-y-2">{qs.map((q, i) => (
              <div key={i} className="bg-gray-50 rounded-xl p-3 text-xs">
                <div className="font-semibold mb-1">Q{i + 1}. {q.question_text}</div>
                <div className="grid grid-cols-2 gap-1 text-gray-500"><div>A) {q.option_a}</div><div>B) {q.option_b}</div><div>C) {q.option_c}</div><div>D) {q.option_d}</div></div>
                <div className="text-emerald-600 font-semibold mt-1">Answer: {q.correct_answer}</div>
              </div>
            ))}</div>
          </ScrollArea>
        </div>
        <div className="flex gap-2">
          <Button type="submit" disabled={ld} className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl text-xs font-semibold px-6 shadow-lg shadow-emerald-500/20">{ld ? '...' : 'Save Changes'}</Button>
          <Button type="button" variant="outline" onClick={() => setCurrentPage('admin-dashboard')} className="rounded-xl text-xs">Cancel</Button>
        </div>
      </form>
    </div>
  );
}

/* ═══════════════════════ UPLOAD TEST ═══════════════════════ */
function UploadTestPage() {
  const { setCurrentPage } = useAppStore();
  const [f, setF] = useState({ title: '', description: '', duration: 30, marks_per_question: 4, class_for: '10th' });
  const [file, setFile] = useState<File | null>(null);
  const [ld, setLd] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); if (!f.title || !file) return toast.error('Title & file required');
    setLd(true);
    try { const fd = new FormData(); fd.append('file', file); fd.append('title', f.title); fd.append('description', f.description); fd.append('duration', f.duration.toString()); fd.append('marks_per_question', f.marks_per_question.toString()); fd.append('class_for', f.class_for);
      const r = await fetch('/api/upload-test', { method: 'POST', body: fd }); const d = await r.json(); d.success ? (toast.success(d.message), setCurrentPage('admin-dashboard')) : toast.error(d.message);
    } catch { toast.error('Error'); }
    setLd(false);
  };
  return (
    <div className="max-w-lg mx-auto px-4 py-8 page-transition">
      <div className="flex items-center gap-3 mb-6"><Button variant="ghost" size="icon" onClick={() => setCurrentPage('admin-dashboard')} className="rounded-xl"><ArrowLeft className="h-4 w-4" /></Button><h1 className="text-xl font-black text-gray-900">Upload Test</h1></div>
      <div className="modern-card rounded-2xl p-6">
        <form onSubmit={submit} className="space-y-4">
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Title</Label><Input required value={f.title} onChange={e => setF({ ...f, title: e.target.value })} className="mt-1 rounded-xl h-11" /></div>
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Description</Label><Textarea value={f.description} onChange={e => setF({ ...f, description: e.target.value })} className="mt-1 rounded-xl" rows={2} /></div>
          <div className="grid grid-cols-3 gap-3">
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Duration</Label><Input type="number" min={1} value={f.duration} onChange={e => setF({ ...f, duration: +e.target.value || 30 })} className="mt-1 rounded-xl h-11" /></div>
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Marks/Q</Label><Input type="number" min={1} value={f.marks_per_question} onChange={e => setF({ ...f, marks_per_question: +e.target.value || 4 })} className="mt-1 rounded-xl h-11" /></div>
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Class</Label><Select value={f.class_for} onValueChange={v => setF({ ...f, class_for: v })}><SelectTrigger className="mt-1 rounded-xl h-11"><SelectValue /></SelectTrigger><SelectContent>{CLS.map(c => <SelectItem key={c} value={c}>Class {c}</SelectItem>)}</SelectContent></Select></div>
          </div>
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">File (TXT)</Label><Input type="file" accept=".txt" onChange={e => setFile(e.target.files?.[0] || null)} className="mt-1 rounded-xl h-11 text-sm" /><p className="text-[10px] text-gray-400 mt-1">Format: Q1. Question? | A) ... | B) ... | C) ... | D) ... | Answer: X</p></div>
          <div className="flex gap-2"><Button type="submit" disabled={ld} className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl h-11 font-semibold text-xs shadow-lg shadow-emerald-500/20">{ld ? '...' : <><Upload className="h-3.5 w-3.5 mr-1.5" />Upload</>}</Button><Button type="button" variant="outline" onClick={() => setCurrentPage('admin-dashboard')} className="rounded-xl text-xs">Cancel</Button></div>
        </form>
      </div>
    </div>
  );
}

/* ═══════════════════════ ADD STUDENT ═══════════════════════ */
function AddStuPage() {
  const { editStudent, setCurrentPage } = useAppStore();
  const isEdit = !!editStudent;
  const [f, setF] = useState({ student_id: editStudent?.student_id || '', roll_number: editStudent?.roll_number || '', name: editStudent?.name || '', email: editStudent?.email || '', password: editStudent?.password || 'student123', class: editStudent?.class || '10th', mobile: editStudent?.mobile || '' });
  const [ld, setLd] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setLd(true);
    try {
      if (isEdit && editStudent) {
        const r = await fetch(`/api/students/${editStudent.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(f) });
        r.ok ? (toast.success('Updated'), setCurrentPage('admin-students')) : toast.error('Error');
      } else {
        const r = await fetch('/api/students', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(f) });
        const d = await r.json(); d.success ? (toast.success('Added'), setCurrentPage('admin-students')) : toast.error(d.message);
      }
    } catch { toast.error('Error'); }
    setLd(false);
  };
  return (
    <div className="max-w-lg mx-auto px-4 py-8 page-transition">
      <div className="flex items-center gap-3 mb-6"><Button variant="ghost" size="icon" onClick={() => setCurrentPage('admin-students')} className="rounded-xl"><ArrowLeft className="h-4 w-4" /></Button><h1 className="text-xl font-black text-gray-900">{isEdit ? 'Edit Student' : 'Add Student'}</h1></div>
      <div className="modern-card rounded-2xl p-6">
        <form onSubmit={submit} className="space-y-4">
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Student ID</Label><Input required value={f.student_id} onChange={e => setF({ ...f, student_id: e.target.value })} className="mt-1 rounded-xl h-11" placeholder="STU006" /></div>
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Roll Number</Label><Input value={f.roll_number} onChange={e => setF({ ...f, roll_number: e.target.value })} className="mt-1 rounded-xl h-11" /></div>
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Name</Label><Input required value={f.name} onChange={e => setF({ ...f, name: e.target.value })} className="mt-1 rounded-xl h-11" /></div>
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Email</Label><Input required type="email" value={f.email} onChange={e => setF({ ...f, email: e.target.value })} className="mt-1 rounded-xl h-11" /></div>
          <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Password</Label><Input value={f.password} onChange={e => setF({ ...f, password: e.target.value })} className="mt-1 rounded-xl h-11" /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Class</Label><Select value={f.class} onValueChange={v => setF({ ...f, class: v })}><SelectTrigger className="mt-1 rounded-xl h-11"><SelectValue /></SelectTrigger><SelectContent>{CLS.map(c => <SelectItem key={c} value={c}>Class {c}</SelectItem>)}</SelectContent></Select></div>
            <div><Label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Mobile</Label><Input value={f.mobile} onChange={e => setF({ ...f, mobile: e.target.value })} className="mt-1 rounded-xl h-11" /></div>
          </div>
          <div className="flex gap-2"><Button type="submit" disabled={ld} className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl h-11 font-bold text-xs shadow-lg shadow-emerald-500/20">{ld ? '...' : (isEdit ? 'Save Changes' : 'Add Student')}</Button><Button type="button" variant="outline" onClick={() => setCurrentPage('admin-students')} className="rounded-xl text-xs">Cancel</Button></div>
        </form>
      </div>
    </div>
  );
}

/* ═══════════════════════ STUDENTS LIST ═══════════════════════ */
function StuListPage() {
  const { lang, setCurrentPage } = useAppStore();
  const tr = T[lang];
  const [stus, setStus] = useState<Array<Record<string, string | number>>>([]);
  const [search, setSearch] = useState('');
  const [showPwd, setShowPwd] = useState(false);
  const [ld, setLd] = useState(true);
  useEffect(() => { (async () => { try { const r = await fetch('/api/students'); const d = await r.json(); if (d.success) setStus(d.students); } catch { /* */ } setLd(false); })(); }, []);
  const filtered = stus.filter((s: Record<string, string | number>) => `${s.name}`.toLowerCase().includes(search.toLowerCase()) || `${s.email}`.toLowerCase().includes(search.toLowerCase()));
  const del = async (id: number) => { if (!confirm('Delete?')) return; try { await fetch(`/api/students/${id}`, { method: 'DELETE' }); setStus(stus.filter(s => s.id !== id)); toast.success('Deleted'); } catch { toast.error('Error'); } };
  return (
    <div className="max-w-7xl mx-auto px-4 py-8 page-transition">
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="icon" onClick={() => setCurrentPage('admin-dashboard')} className="rounded-xl"><ArrowLeft className="h-4 w-4" /></Button>
        <h1 className="text-xl font-black text-gray-900">{tr.stuRec}</h1>
        <Button className="ml-auto bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl text-xs h-9 shadow-md shadow-emerald-500/20" onClick={() => { useAppStore.getState().setEditStudent(null); setCurrentPage('admin-add-student'); }}><Plus className="h-3.5 w-3.5 mr-1" />Add</Button>
      </div>
      <div className="flex items-center gap-3 mb-4">
        <div className="relative flex-1 max-w-sm"><Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-300" /><Input placeholder={tr.search} value={search} onChange={e => setSearch(e.target.value)} className="pl-10 rounded-xl h-10 text-sm" /></div>
        <Button variant="outline" size="sm" onClick={() => setShowPwd(!showPwd)} className="rounded-xl text-xs border-gray-200">{showPwd ? <EyeOff className="h-3.5 w-3.5 mr-1" /> : <Eye className="h-3.5 w-3.5 mr-1" />}{showPwd ? tr.hidePwd : tr.showPwd}</Button>
      </div>
      <div className="modern-card rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow className="bg-gray-50/80">
              <TableHead className="text-[10px] font-bold">ID</TableHead><TableHead className="text-[10px] font-bold">Name</TableHead><TableHead className="text-[10px] font-bold">Email</TableHead><TableHead className="text-[10px] font-bold">Class</TableHead>
              {showPwd && <TableHead className="text-[10px] font-bold">Password</TableHead>}
              <TableHead className="text-[10px] font-bold text-right">Actions</TableHead>
            </TableRow></TableHeader>
            <TableBody>{ld ? <TableRow><TableCell colSpan={7} className="py-8 text-center text-gray-300 text-xs">Loading...</TableCell></TableRow> :
              filtered.length === 0 ? <TableRow><TableCell colSpan={7} className="py-8 text-center text-gray-300 text-xs">{tr.noStu}</TableCell></TableRow> :
              filtered.map((s: Record<string, string | number>) => (
                <TableRow key={s.id}>
                  <TableCell className="font-mono text-xs text-gray-500">{s.student_id}</TableCell>
                  <TableCell className="font-semibold text-xs">{s.name}</TableCell>
                  <TableCell className="text-xs text-gray-500">{s.email}</TableCell>
                  <TableCell><Badge variant="outline" className="text-[10px] border-gray-200">{s.class}</Badge></TableCell>
                  {showPwd && <TableCell className="font-mono text-[10px] text-gray-400">{s.password as string}</TableCell>}
                  <TableCell className="text-right">
                    <Button size="sm" variant="ghost" onClick={() => { useAppStore.getState().setViewStudentResults({ id: s.id as number, name: s.name as string, student_id: s.student_id as string, class: s.class as string }); setCurrentPage('admin-view-student'); }} className="h-7 w-7 p-0 rounded-lg text-gray-400 hover:text-emerald-600"><BarChart3 className="h-3.5 w-3.5" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => { useAppStore.getState().setEditStudent(s as never); setCurrentPage('admin-add-student'); }} className="h-7 w-7 p-0 rounded-lg text-gray-400 hover:text-amber-600"><Edit className="h-3.5 w-3.5" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => del(s.id as number)} className="h-7 w-7 p-0 rounded-lg text-gray-400 hover:text-red-500"><Trash2 className="h-3.5 w-3.5" /></Button>
                  </TableCell>
                </TableRow>
              ))}</TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════ VIEW STUDENT RESULTS ═══════════════════════ */
function ViewStuResPage() {
  const { viewStudentResults, setCurrentPage } = useAppStore();
  const [results, setResults] = useState<ExamResult[]>([]);
  const [sel, setSel] = useState<ExamResult | null>(null);
  const [ld, setLd] = useState(true);
  useEffect(() => { if (!viewStudentResults) return; (async () => { try { const r = await fetch(`/api/results/student/${viewStudentResults.id}`); const d = await r.json(); if (d.success) setResults(d.results); } catch { /* */ } setLd(false); })(); }, [viewStudentResults]);
  if (!viewStudentResults) return <div className="text-center py-20 text-gray-400">No student</div>;

  if (sel) return (
    <div className="max-w-4xl mx-auto px-4 py-8 page-transition">
      <Button variant="ghost" onClick={() => setSel(null)} className="mb-4 rounded-xl text-xs"><ArrowLeft className="h-3.5 w-3.5 mr-1" />Back</Button>
      <div className="modern-card rounded-2xl p-6 mb-6">
        <div className="flex flex-wrap gap-6 justify-center"><div className="text-center"><div className="text-3xl font-black text-emerald-600">{sel.percentage}%</div><div className="text-[10px] text-gray-400">Percentage</div></div><div className="h-12 w-px bg-gray-100 hidden md:block" /><div className="text-center"><div className="text-3xl font-black text-gray-900">{sel.score}/{sel.totalMarks}</div><div className="text-[10px] text-gray-400">Score</div></div></div>
      </div>
      <div className="modern-card rounded-2xl overflow-hidden">
        <div className="overflow-x-auto"><Table>
          <TableHeader><TableRow className="bg-gray-50/80"><TableHead className="w-10 text-[10px] font-bold">#</TableHead><TableHead className="text-[10px] font-bold">Question</TableHead><TableHead className="text-[10px] font-bold">Yours</TableHead><TableHead className="text-[10px] font-bold">Correct</TableHead><TableHead className="text-[10px] font-bold">Status</TableHead><TableHead className="text-[10px] font-bold">Marks</TableHead></TableRow></TableHeader>
          <TableBody>{sel.detailed_answers?.map((a: DetailedAnswer, i: number) => (
            <TableRow key={i}><TableCell className="font-bold text-xs">{i + 1}</TableCell><TableCell className="text-xs max-w-[220px] truncate">{a.question_text}</TableCell><TableCell className={`text-xs font-semibold ${a.is_correct ? 'text-emerald-600' : 'text-red-500'}`}>{a.student_answer || '-'}</TableCell><TableCell className="text-xs font-semibold text-emerald-600">{a.correct_answer}</TableCell><TableCell>{a.is_correct ? <Badge className="bg-emerald-100 text-emerald-700 text-[10px]"><CheckCircle className="h-3 w-3 mr-0.5" /></Badge> : <Badge className="bg-red-100 text-red-600 text-[10px]"><XCircle className="h-3 w-3 mr-0.5" /></Badge>}</TableCell><TableCell className="font-bold text-xs">{a.marks_obtained}</TableCell></TableRow>
          ))}</TableBody>
        </Table></div>
      </div>
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 page-transition">
      <div className="flex items-center gap-3 mb-6"><Button variant="ghost" size="icon" onClick={() => setCurrentPage('admin-students')} className="rounded-xl"><ArrowLeft className="h-4 w-4" /></Button><div><h1 className="text-xl font-black text-gray-900">{viewStudentResults.name}</h1><p className="text-[10px] text-gray-400">{viewStudentResults.student_id} | Class {viewStudentResults.class}</p></div></div>
      <div className="modern-card rounded-2xl overflow-hidden">
        <div className="overflow-x-auto"><Table>
          <TableHeader><TableRow className="bg-gray-50/80"><TableHead className="text-[10px] font-bold">Test</TableHead><TableHead className="text-[10px] font-bold">Score</TableHead><TableHead className="text-[10px] font-bold">%</TableHead><TableHead className="text-[10px] font-bold">Date</TableHead><TableHead className="text-[10px] font-bold text-right">Action</TableHead></TableRow></TableHeader>
          <TableBody>{ld ? <TableRow><TableCell colSpan={5} className="py-8 text-center text-gray-300 text-xs">Loading...</TableCell></TableRow> :
            results.length === 0 ? <TableRow><TableCell colSpan={5} className="py-8 text-center text-gray-300 text-xs">No results</TableCell></TableRow> :
            results.map((r, i) => (
              <TableRow key={i}><TableCell className="text-xs font-semibold max-w-[250px] truncate">{r.test?.title || r.test_title}</TableCell><TableCell className="text-xs">{r.score}/{r.totalMarks}</TableCell><TableCell><Badge className={`text-[10px] ${r.percentage >= 60 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-600'}`}>{r.percentage}%</Badge></TableCell><TableCell className="text-xs text-gray-400">{new Date(r.submitted_at).toLocaleDateString()}</TableCell><TableCell className="text-right"><Button size="sm" variant="outline" onClick={() => setSel(r)} className="rounded-lg text-[10px] border-gray-200 text-emerald-600 h-7">View</Button></TableCell></TableRow>
            ))}</TableBody>
        </Table></div>
      </div>
    </div>
  );
}
