import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const { name, email, mobile, class: studentClass, medium, message } = data;

    if (!name || !email || !mobile) {
      return NextResponse.json({ success: false, message: 'Name, email and mobile are required' }, { status: 400 });
    }

    const registration = await db.registration.create({
      data: {
        name,
        email,
        mobile,
        class: studentClass || '10th',
        medium: medium || 'English Medium',
        message: message || '',
      },
    });

    return NextResponse.json({ success: true, registration });
  } catch {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}
