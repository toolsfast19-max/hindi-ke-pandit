import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const { student_id, test_id, answers } = await request.json();

    if (!student_id || !test_id || !answers) {
      return NextResponse.json({ success: false, message: 'Missing required fields' }, { status: 400 });
    }

    // Get the test and questions
    const test = await db.test.findUnique({
      where: { id: parseInt(test_id) },
      include: { questions: { orderBy: { id: 'asc' } } },
    });

    if (!test) {
      return NextResponse.json({ success: false, message: 'Test not found' }, { status: 404 });
    }

    // Check if student already submitted
    const existingResult = await db.result.findFirst({
      where: {
        student_id: parseInt(student_id),
        test_id: parseInt(test_id),
      },
    });

    if (existingResult) {
      return NextResponse.json({ success: false, message: 'You have already submitted this test' }, { status: 400 });
    }

    // Calculate score - use robust comparison
    let score = 0;
    const detailedAnswers = test.questions.map((q, index) => {
      const studentAnswer = answers[index] || null;

      // Normalize both answers for comparison: trim whitespace, uppercase
      const normalize = (s: string | null): string | null => {
        if (!s) return null;
        return s.trim().toUpperCase();
      };

      const normalizedStudent = normalize(studentAnswer);
      const normalizedCorrect = normalize(q.correct_answer);
      const isCorrect = normalizedStudent !== null && normalizedStudent === normalizedCorrect;

      if (isCorrect) score += test.marks_per_question;

      return {
        question_number: index + 1,
        question_text: q.question_text,
        option_a: q.option_a,
        option_b: q.option_b,
        option_c: q.option_c,
        option_d: q.option_d,
        correct_answer: q.correct_answer.trim().toUpperCase(),
        student_answer: studentAnswer ? studentAnswer.trim().toUpperCase() : null,
        is_correct: isCorrect,
        marks_obtained: isCorrect ? test.marks_per_question : 0,
      };
    });

    const totalMarks = test.questions.length * test.marks_per_question;
    const percentage = totalMarks > 0 ? (score / totalMarks) * 100 : 0;

    // Save result
    const result = await db.result.create({
      data: {
        student_id: parseInt(student_id),
        test_id: parseInt(test_id),
        score,
        total_questions: test.questions.length,
        percentage: Math.round(percentage * 100) / 100,
        answers: JSON.stringify(detailedAnswers),
      },
    });

    return NextResponse.json({
      success: true,
      result: {
        id: result.id,
        score,
        total_questions: test.questions.length,
        total_marks: totalMarks,
        percentage: Math.round(percentage * 100) / 100,
        detailed_answers: detailedAnswers,
        test_title: test.title,
        submitted_at: result.submitted_at,
      },
    });
  } catch (error) {
    console.error('Submit exam error:', error);
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}
