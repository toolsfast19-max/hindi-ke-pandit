import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const questions = await db.question.findMany({
      where: { test_id: parseInt(id) },
      orderBy: { id: 'asc' },
    });

    return NextResponse.json({ success: true, questions });
  } catch {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}
