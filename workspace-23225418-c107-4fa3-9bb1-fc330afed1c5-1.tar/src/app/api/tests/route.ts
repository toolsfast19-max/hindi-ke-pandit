import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const tests = await db.test.findMany({
      include: {
        _count: { select: { questions: true, results: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ success: true, tests });
  } catch {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    const { title, description, duration, marks_per_question, class_for, questions } = data;

    const test = await db.test.create({
      data: {
        title,
        description: description || '',
        duration: duration || 30,
        marks_per_question: marks_per_question || 4,
        class_for: class_for || 'All',
      },
    });

    if (questions && Array.isArray(questions)) {
      for (const q of questions) {
        await db.question.create({
          data: {
            test_id: test.id,
            question_text: q.question_text,
            option_a: q.option_a,
            option_b: q.option_b,
            option_c: q.option_c,
            option_d: q.option_d,
            correct_answer: q.correct_answer || 'A',
          },
        });
      }
    }

    const updatedTest = await db.test.findUnique({
      where: { id: test.id },
      include: { _count: { select: { questions: true } } },
    });

    return NextResponse.json({ success: true, test: updatedTest });
  } catch (error) {
    console.error('Create test error:', error);
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 });
  }
}
