import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type Page =
  | 'home'
  | 'about'
  | 'courses'
  | 'contact'
  | 'register'
  | 'student-login'
  | 'admin-login'
  | 'student-dashboard'
  | 'student-exam'
  | 'student-result'
  | 'student-results-list'
  | 'admin-dashboard'
  | 'admin-add-test'
  | 'admin-edit-test'
  | 'admin-upload-test'
  | 'admin-add-student'
  | 'admin-students'
  | 'admin-view-student'
  | 'admin-results';

export interface Student {
  id: number;
  student_id: string;
  roll_number: string;
  name: string;
  email: string;
  photo: string;
  class: string;
  mobile: string;
}

export interface Test {
  id: number;
  title: string;
  description: string;
  duration: number;
  total_questions: number;
  marks_per_question: number;
  class_for: string;
  createdAt: string;
  _count?: { questions: number; results: number };
}

export interface Question {
  id: number;
  test_id: number;
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_answer: string;
}

export interface DetailedAnswer {
  question_number: number;
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_answer: string;
  student_answer: string | null;
  is_correct: boolean;
  marks_obtained: number;
}

export interface ExamResult {
  id: number;
  score: number;
  total_questions: number;
  total_marks: number;
  percentage: number;
  detailed_answers: DetailedAnswer[];
  test_title: string;
  submitted_at: string;
  test?: { id: number; title: string; class_for: string };
  student?: { id: number; name: string; student_id: string; class: string };
}

interface AppState {
  // Navigation
  currentPage: Page;
  setCurrentPage: (page: Page) => void;

  // Language
  lang: 'en' | 'mr';
  setLang: (lang: 'en' | 'mr') => void;

  // Admin Auth
  isAdminLoggedIn: boolean;
  adminLogin: (token: string) => void;
  adminLogout: () => void;

  // Student Auth
  isStudentLoggedIn: boolean;
  student: Student | null;
  studentLogin: (student: Student, token: string) => void;
  studentLogout: () => void;

  // Current Exam State
  currentTest: Test | null;
  currentQuestions: Question[];
  examAnswers: (string | null)[];
  examStartTime: number | null;
  setCurrentTest: (test: Test, questions: Question[]) => void;
  setExamAnswer: (index: number, answer: string | null) => void;
  startExam: () => void;
  clearExamState: () => void;

  // Result to display
  currentResult: ExamResult | null;
  setCurrentResult: (result: ExamResult) => void;

  // Edit mode
  editTest: Test | null;
  setEditTest: (test: Test | null) => void;
  editStudent: { id: number; name: string; email: string; student_id: string; roll_number: string; class: string; mobile: string; password: string; photo: string } | null;
  setEditStudent: (student: typeof AppState extends { editStudent: infer T } ? T : never) => void;

  // Student results view
  viewStudentResults: { id: number; name: string; student_id: string; class: string } | null;
  setViewStudentResults: (student: typeof AppState extends { viewStudentResults: infer T } ? T : never) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      // Navigation
      currentPage: 'home',
      setCurrentPage: (page) => set({ currentPage: page }),

      // Language
      lang: 'en',
      setLang: (lang) => set({ lang }),

      // Admin Auth
      isAdminLoggedIn: false,
      adminLogin: () => set({ isAdminLoggedIn: true }),
      adminLogout: () => set({ isAdminLoggedIn: false, currentPage: 'home' }),

      // Student Auth
      isStudentLoggedIn: false,
      student: null,
      studentLogin: (student) => set({ isStudentLoggedIn: true, student, currentPage: 'student-dashboard' }),
      studentLogout: () => set({ isStudentLoggedIn: false, student: null, currentPage: 'home', clearExamState: () => set({ currentTest: null, currentQuestions: [], examAnswers: [], examStartTime: null }) }),

      // Current Exam
      currentTest: null,
      currentQuestions: [],
      examAnswers: [],
      examStartTime: null,
      setCurrentTest: (test, questions) => set({
        currentTest: test,
        currentQuestions: questions,
        examAnswers: new Array(questions.length).fill(null),
      }),
      setExamAnswer: (index, answer) => set((state) => {
        const newAnswers = [...state.examAnswers];
        newAnswers[index] = answer;
        return { examAnswers: newAnswers };
      }),
      startExam: () => set({ examStartTime: Date.now() }),
      clearExamState: () => set({ currentTest: null, currentQuestions: [], examAnswers: [], examStartTime: null }),

      // Result
      currentResult: null,
      setCurrentResult: (result) => set({ currentResult: result }),

      // Edit test
      editTest: null,
      setEditTest: (test) => set({ editTest: test }),

      // Edit student
      editStudent: null,
      setEditStudent: (student) => set({ editStudent: student }),

      // View student results
      viewStudentResults: null,
      setViewStudentResults: (student) => set({ viewStudentResults: student }),
    }),
    {
      name: 'shrinath-chanakya-app',
      partialize: (state) => ({
        isAdminLoggedIn: state.isAdminLoggedIn,
        isStudentLoggedIn: state.isStudentLoggedIn,
        student: state.student,
        lang: state.lang,
      }),
    }
  )
);
